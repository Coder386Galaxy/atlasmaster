/* Droply — shared client library (uploads, API, domain checkout) */
window.Droply = (function () {
  const TEXT_EXT = new Set(['html', 'htm', 'css', 'js', 'mjs', 'cjs', 'json', 'svg', 'txt', 'md', 'markdown',
    'yml', 'yaml', 'xml', 'toml', 'ini', 'csv', 'map', 'ts', 'tsx', 'jsx', 'py', 'rb', 'go', 'rs', 'java',
    'php', 'sh', 'env', 'gitignore', 'robots', 'webmanifest']);

  /* ---------------- utils ---------------- */
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const money = (n) => '$' + Number(n || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  const bytes = (n) => {
    n = Number(n) || 0;
    const u = ['B', 'KB', 'MB', 'GB', 'TB'];
    let i = 0; while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
    return (i === 0 ? n : n.toFixed(n < 10 ? 1 : 0)) + ' ' + u[i];
  };
  const num = (n) => (Number(n) || 0).toLocaleString('en-US');
  function timeAgo(ts) {
    const s = (Date.now() - ts) / 1000;
    if (s < 60) return 'just now';
    if (s < 3600) return Math.floor(s / 60) + 'm ago';
    if (s < 86400) return Math.floor(s / 3600) + 'h ago';
    if (s < 2592000) return Math.floor(s / 86400) + 'd ago';
    return new Date(ts).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  }
  function dateStr(ts) { return new Date(ts).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }); }

  function toast(title, msg, type = 'ok', ms = 5200) {
    let wrap = $('.toast-wrap');
    if (!wrap) { wrap = document.createElement('div'); wrap.className = 'toast-wrap'; document.body.appendChild(wrap); }
    const el = document.createElement('div');
    el.className = 'toast ' + (type === 'err' ? 'err' : type === 'ok' ? 'ok' : '');
    el.innerHTML = `<div><div class="t">${esc(title)}</div>${msg ? `<div class="d">${esc(msg)}</div>` : ''}</div>`;
    wrap.appendChild(el);
    setTimeout(() => { el.style.opacity = '0'; el.style.transform = 'translateY(8px)'; el.style.transition = '.25s'; }, ms);
    setTimeout(() => el.remove(), ms + 300);
  }

  async function api(path, opts = {}) {
    const res = await fetch(path, Object.assign({
      headers: { 'content-type': 'application/json' },
    }, opts, opts.body && typeof opts.body !== 'string' ? { body: JSON.stringify(opts.body) } : {}));
    let data = null;
    try { data = await res.json(); } catch (e) { }
    if (!res.ok || (data && data.ok === false)) {
      throw new Error((data && data.error) || ('Request failed (' + res.status + ')'));
    }
    return data;
  }

  /* ---------------- file collection ---------------- */
  function readAllEntries(reader) {
    return new Promise((resolve) => {
      const all = [];
      (function next() {
        reader.readEntries((es) => {
          if (!es.length) return resolve(all);
          all.push(...es);
          next();
        }, () => resolve(all));
      })();
    });
  }
  async function readEntries(entries, prefix = '') {
    const out = [];
    for (const e of entries) {
      if (e.isFile) {
        const f = await new Promise((r) => e.file(r, () => r(null)));
        if (f) out.push({ file: f, path: prefix + f.name });
      } else if (e.isDirectory) {
        const kids = await readAllEntries(e.createReader());
        out.push(...await readEntries(kids, prefix + e.name + '/'));
      }
    }
    return out;
  }
  async function filesFromDataTransfer(dt) {
    const items = dt.items ? Array.from(dt.items) : [];
    const entries = items.map(i => i.webkitGetAsEntry && i.webkitGetAsEntry()).filter(Boolean);
    if (entries.length) return await readEntries(entries);
    return Array.from(dt.files || []).map(f => ({ file: f, path: f.name }));
  }
  const MAX_TOTAL = 40 * 1024 * 1024;

  async function toPayload(list, onProgress) {
    const files = [];
    let total = 0, skipped = 0;
    for (let i = 0; i < list.length; i++) {
      const { file, path } = list[i];
      if (typeof onProgress === 'function') onProgress(i / list.length, file.name);
      if (total + file.size > MAX_TOTAL) { skipped++; continue; }
      const ext = (path.split('.').pop() || '').toLowerCase();
      const isText = TEXT_EXT.has(ext) || file.type.startsWith('text/') ||
        ['application/json', 'application/javascript', 'image/svg+xml'].includes(file.type);
      const p = sanitizeUploadPath(path);
      if (!p) continue;
      if (isText) {
        files.push({ path: p, content: await file.text() });
      } else {
        const b64 = await new Promise((res, rej) => {
          const fr = new FileReader();
          fr.onload = () => res(String(fr.result).split(',')[1]);
          fr.onerror = rej;
          fr.readAsDataURL(file);
        });
        files.push({ path: p, b64 });
      }
      total += file.size;
    }
    if (typeof onProgress === 'function') onProgress(1, 'done');
    return { files, total, skipped };
  }
  function sanitizeUploadPath(p) {
    let s = String(p).replace(/\\/g, '/').replace(/^\/+/, '');
    const parts = [];
    for (const seg of s.split('/')) {
      if (!seg || seg === '.') continue;
      if (seg === '..' || seg.startsWith('__MACOSX') || seg === '.DS_Store') return null;
      parts.push(seg);
    }
    return parts.length ? parts.join('/') : null;
  }

  /** Wire a dropzone element: drop, click-to-pick, optional folder/file inputs. */
  function dropzone(el, { onFiles } = {}) {
    if (!el) return;
    const stop = (e) => { e.preventDefault(); e.stopPropagation(); };
    ['dragenter', 'dragover'].forEach(t => el.addEventListener(t, e => { stop(e); el.classList.add('over'); }));
    ['dragleave', 'drop'].forEach(t => el.addEventListener(t, e => { stop(e); el.classList.remove('over'); }));
    el.addEventListener('drop', async (e) => {
      const list = await filesFromDataTransfer(e.dataTransfer);
      if (list.length) onFiles(list);
    });
    // keep the whole window from navigating on stray drops
    ['dragover', 'drop'].forEach(t => window.addEventListener(t, e => { if (!el.contains(e.target)) e.preventDefault(); }));
  }

  /* ---------------- domain search + checkout ---------------- */
  async function searchDomains(query) {
    return (await api('/api/domains/search', { method: 'POST', body: { query } }));
  }

  function priceRow(info, onBuy) {
    const avail = info.available && !info.owned;
    return `<div class="dom-row ${avail ? '' : 'na'}">
      <div class="dn">${esc(info.name)}${info.premium ? ' <span class="prem">PREMIUM</span>' : ''}</div>
      <div class="dp">${info.owned ? 'In your account' : avail ? (info.unsupportedTld ? 'Unsupported extension' : money(info.price) + '<span class="yr">/yr</span>') : 'Taken'}</div>
      <div class="da">${info.owned
        ? '<button class="btn sm" data-manage="1">Manage</button>'
        : avail && !info.unsupportedTld
          ? `<button class="btn sm primary" data-buy="${esc(info.name)}">Try checkout</button>`
          : '<button class="btn sm" disabled>Unavailable</button>'}</div>
    </div>`;
  }
  function renderDomainList(container, items, onBuy) {
    container.innerHTML = items.map(i => priceRow(i, onBuy)).join('');
    container.querySelectorAll('[data-buy]').forEach(b => b.addEventListener('click', () => onBuy(b.dataset.buy)));
    container.querySelectorAll('[data-manage]').forEach(b => b.addEventListener('click', () => {
      location.href = '/dashboard#domains';
    }));
  }

  let checkoutOpen = false;
  async function openCheckout(name, opts = {}) {
    if (checkoutOpen) return;
    checkoutOpen = true;
    let years = 1, price = opts.price || 12, premium = !!opts.premium;
    let sites = [];
    try { const s = await api('/api/sites'); sites = s.sites; } catch (e) { }

    const back = document.createElement('div');
    back.className = 'modal-back';
    back.innerHTML = `<div class="modal" style="max-width:520px">
      <h3>Try demo checkout for <span class="mono" style="color:var(--brand)">${esc(name)}</span></h3>
      <p class="sub" style="margin-bottom:16px">Demo checkout only: availability and pricing are simulated. No domain is registered, no DNS changes are made, and no money is charged.</p>

      <div class="field">
        <label>Registration period</label>
        <select class="input" id="co-years">
          ${[1, 2, 3, 5, 10].map(y => `<option value="${y}"${y === 1 ? ' selected' : ''}>${y} year${y > 1 ? 's' : ''}</option>`).join('')}
        </select>
      </div>
      <div class="field">
        <label>Point it at a site</label>
        <select class="input" id="co-site">
          <option value="">Attach later</option>
          ${sites.map(s => `<option value="${s.id}">${esc(s.name)} — ${esc(s.slug)}</option>`).join('')}
        </select>
      </div>

      <div class="panel" style="margin:16px 0 18px">
        <div class="panel-bd" style="padding:14px 16px">
          <div class="sum-row"><span>${esc(name)} registration · <span id="co-y">1</span> yr</span><b id="co-sub">$12.00</b></div>
          <div class="sum-row dim"><span>ICANN fee</span><span id="co-icann">$0.18</span></div>
          <div class="sum-row dim"><span>Taxes</span><span id="co-tax">$1.07</span></div>
          <div class="sum-row total"><span>Simulated total (no charge)</span><b id="co-total">$13.25</b></div>
        </div>
      </div>

      <h4 style="margin:0 0 10px;font-size:14px">Test card fields <span class="hint" style="float:right;font-weight:400">no real charge</span></h4>
      <div class="field"><label>Test card number — do not enter a real card</label><input class="input" id="co-num" placeholder="4242 4242 4242 4242" inputmode="numeric" autocomplete="off"></div>
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px">
        <div class="field"><label>Expiry</label><input class="input" id="co-exp" placeholder="04/29" autocomplete="off"></div>
        <div class="field"><label>CVC</label><input class="input" id="co-cvc" placeholder="123" autocomplete="off"></div>
        <div class="field"><label>ZIP</label><input class="input" id="co-zip" placeholder="94549" autocomplete="off"></div>
      </div>
      <p class="hint" style="margin:-6px 0 16px">Test card: <span class="mono">4242 4242 4242 4242</span> — any future expiry, CVC and ZIP.</p>
      <div class="acts">
        <button class="btn ghost" id="co-cancel">Cancel</button>
        <button class="btn primary" id="co-pay">Simulate order <span id="co-payamt"></span></button>
      </div>
    </div>`;
    document.body.appendChild(back);

    const q = (s) => back.querySelector(s);
    function update() {
      const y = +q('#co-years').value;
      const subtotal = +(price * y).toFixed(2);
      const icann = +(0.18 * y).toFixed(2);
      const tax = +((subtotal + icann) * 0.0875).toFixed(2);
      const total = +(subtotal + icann + tax).toFixed(2);
      q('#co-y').textContent = y;
      q('#co-sub').textContent = money(subtotal);
      q('#co-icann').textContent = money(icann);
      q('#co-tax').textContent = money(tax);
      q('#co-total').textContent = money(total);
      q('#co-payamt').textContent = money(total);
    }
    q('#co-years').addEventListener('change', update);
    update();

    const close = () => { back.remove(); checkoutOpen = false; };
    q('#co-cancel').addEventListener('click', close);
    back.addEventListener('click', (e) => { if (e.target === back) close(); });
    document.addEventListener('keydown', function escClose(e) {
      if (e.key === 'Escape') { close(); document.removeEventListener('keydown', escClose); }
    });

    q('#co-pay').addEventListener('click', async () => {
      const btn = q('#co-pay');
      btn.disabled = true; btn.textContent = 'Processing…';
      try {
        const r = await api('/api/domains/purchase', {
          method: 'POST',
          body: {
            name, years: +q('#co-years').value,
            siteId: q('#co-site').value || null,
            card: {
              number: q('#co-num').value, expiry: q('#co-exp').value,
              cvc: q('#co-cvc').value, zip: q('#co-zip').value,
            },
          },
        });
        close();
        toast('Demo order saved', `${r.domain.name} was not registered and no money was charged — receipt ${r.order.id}`, 'ok', 8000);
        if (opts.onDone) opts.onDone(r);
      } catch (e) {
        btn.disabled = false; btn.innerHTML = 'Simulate order <span id="co-payamt">' + q('#co-total').textContent + '</span>';
        toast('Demo validation failed', e.message, 'err', 7000);
      }
    });
  }

  return {
    $, $$, esc, money, bytes, num, timeAgo, dateStr, toast, api,
    filesFromDataTransfer, toPayload, dropzone, sanitizeUploadPath,
    searchDomains, renderDomainList, openCheckout,
  };
})();

/* Droply — marketing site interactions */
(function () {
  const D = window.Droply, $ = D.$;
  document.getElementById('yr').textContent = new Date().getFullYear();

  /* ---------- terminal log ---------- */
  const term = $('#hero-term'), tbody = $('#term-body');
  let logLines = [];
  function log(html, cls) {
    logLines.push(`<span class="${cls || ''}">${html}</span>`);
    tbody.innerHTML = logLines.join('\n');
    tbody.parentElement.parentElement.scrollTop = 1e9;
    term.style.display = 'block';
  }
  function resetLog() { logLines = []; tbody.innerHTML = ''; }

  /* ---------- deploy helpers ---------- */
  function showResult(site) {
    const el = $('#hero-result');
    el.style.display = 'block';
    el.innerHTML = `<div class="panel" style="margin:0">
      <div class="panel-bd" style="display:flex;gap:16px;align-items:center;flex-wrap:wrap">
        <div style="flex:1;min-width:240px">
          <div style="font-size:12px;color:var(--dim);text-transform:uppercase;letter-spacing:.06em;font-weight:700">Live at</div>
          <a class="mono" href="${site.url}" target="_blank" rel="noopener" style="font-size:16px;word-break:break-all">${site.url}</a>
          <div style="margin-top:8px"><span class="badge"><span class="p"></span>Published</span>
            <span class="hint" style="margin-left:8px">${site.files} file${site.files === 1 ? '' : 's'} · deploy ${site.activeDeploy}</span></div>
        </div>
        <div style="display:flex;gap:8px;flex-wrap:wrap">
          <a class="btn primary" href="${site.url}" target="_blank" rel="noopener">Open site ↗</a>
          <button class="btn" id="copy-url" data-url="${site.url}">Copy URL</button>
          <a class="btn" href="/dashboard">Open dashboard</a>
        </div>
      </div>
    </div>`;
    $('#copy-url').addEventListener('click', async (e) => {
      try { await navigator.clipboard.writeText(e.currentTarget.dataset.url); D.toast('Copied', e.currentTarget.dataset.url); }
      catch (err) { D.toast('Copy failed', 'Select and copy the URL manually', 'err'); }
    });
  }

  async function deploy({ files, name, source, message }) {
    resetLog();
    const t0 = Date.now();
    log(`<span class="dim">$</span> droply deploy ./${name}`);
    log(`<span class="dim">•</span> packaging ${files.length} file${files.length === 1 ? '' : 's'} …`);
    const r = await D.api('/api/deploy', {
      method: 'POST',
      body: { files, name, source, message: message || `Deployed from ${source}` },
    });
    const site = r.site;
    log(`<span class="ok">✓</span> uploaded ${D.bytes(site.size)}`);
    log(`<span class="ok">✓</span> deploy ${site.activeDeploy} is live`);
    log(`<span class="ok">✓</span> <a href="${site.url}" target="_blank" rel="noopener">${site.url}</a>`);
    log(`<span class="dim">Done in ${((Date.now() - t0) / 1000).toFixed(1)}s</span>`);
    showResult(site);
    D.toast('Site is live', site.url, 'ok');
    return site;
  }

  async function handleList(list) {
    const name = (list[0]?.path || 'site').split('/')[0].replace(/\.(zip)$/i, '') || 'site';
    log(`<span class="dim">•</span> reading ${list.length} item${list.length === 1 ? '' : 's'} …`);
    let logged = 0;
    const { files, skipped } = await D.toPayload(list, (p, f) => {
      if (logged < 12) { log(`<span class="dim">…</span> ${D.esc(f)}`); logged++; }
      else if (logged === 12) { log(`<span class="dim">…</span> ${list.length - 12} more`); logged++; }
    });
    if (!files.length) { D.toast('Nothing to deploy', 'That drop had no readable files', 'err'); return; }
    if (skipped) D.toast('Some files skipped', `${skipped} file(s) exceeded the 40 MB deploy limit`, 'err');
    await deploy({ files, name, source: 'drag & drop' });
  }

  D.dropzone($('#hero-drop'), { onFiles: handleList });
  $('#hero-drop').addEventListener('click', () => $('#pick-folder').click());

  // folder picker
  const folderInput = document.createElement('input');
  folderInput.type = 'file'; folderInput.webkitdirectory = true; folderInput.multiple = true;
  folderInput.style.display = 'none'; document.body.appendChild(folderInput);
  folderInput.addEventListener('change', async () => {
    const list = Array.from(folderInput.files).map(f => ({ file: f, path: f.webkitRelativePath || f.name }));
    if (list.length) await handleList(list);
    folderInput.value = '';
  });
  $('#pick-folder').addEventListener('click', (e) => { e.stopPropagation(); folderInput.click(); });

  // file picker
  const fileInput = document.createElement('input');
  fileInput.type = 'file'; fileInput.multiple = true; fileInput.style.display = 'none';
  document.body.appendChild(fileInput);
  fileInput.addEventListener('change', async () => {
    const list = Array.from(fileInput.files).map(f => ({ file: f, path: f.name }));
    if (list.length) await handleList(list);
    fileInput.value = '';
  });
  $('#pick-files').addEventListener('click', (e) => { e.stopPropagation(); fileInput.click(); });

  // paste HTML
  $('#paste-toggle').addEventListener('click', () => {
    const b = $('#paste-box');
    b.style.display = b.style.display === 'none' ? 'block' : 'none';
    if (b.style.display === 'block') $('#paste-html').focus();
  });
  $('#paste-deploy').addEventListener('click', async () => {
    const html = $('#paste-html').value.trim();
    if (!html) return D.toast('Nothing to deploy', 'Paste some HTML first', 'err');
    await deploy({
      files: [{ path: 'index.html', content: html }],
      name: 'pasted-site', source: 'paste', message: 'Deployed pasted HTML',
    });
  });

  // GitHub import
  $('#gh-toggle').addEventListener('click', () => {
    const b = $('#gh-box');
    b.style.display = b.style.display === 'none' ? 'block' : 'none';
    if (b.style.display === 'block') $('#gh-repo').focus();
  });
  $('#gh-deploy').addEventListener('click', async () => {
    const repo = $('#gh-repo').value.trim();
    if (!repo) return D.toast('Repository required', 'Paste a GitHub URL', 'err');
    resetLog();
    log(`<span class="dim">$</span> droply import ${D.esc(repo)}`);
    try {
      const r = await D.api('/api/import-github', { method: 'POST', body: { repo } });
      log(`<span class="ok">✓</span> downloaded &amp; extracted ${r.site.files} files`);
      log(`<span class="ok">✓</span> <a href="${r.site.url}" target="_blank" rel="noopener">${r.site.url}</a>`);
      showResult(r.site);
      D.toast('Imported', r.site.url, 'ok');
    } catch (e) {
      log(`<span class="err">✗ ${D.esc(e.message)}</span>`);
      D.toast('Import failed', e.message, 'err');
    }
  });

  /* ---------- domain search ---------- */
  const domQ = $('#dom-q'), domResults = $('#dom-results');
  const TLDS = ['com', 'io', 'dev', 'net', 'co', 'app', 'ai', 'xyz', 'org', 'me', 'sh', 'page'];
  $('#tld-chips').innerHTML = TLDS.map(t => `<button data-tld="${t}">.${t}</button>`).join('');
  let activeTld = null;
  $('#tld-chips').addEventListener('click', (e) => {
    const b = e.target.closest('[data-tld]'); if (!b) return;
    activeTld = activeTld === b.dataset.tld ? null : b.dataset.tld;
    D.$$('#tld-chips button').forEach(x => x.classList.toggle('on', x.dataset.tld === activeTld));
    if (domQ.value.trim()) runSearch(domQ.value.trim());
  });

  async function runSearch(q) {
    domResults.innerHTML = `<div class="dom-list"><div class="dom-head"><span>Checking availability…</span></div></div>`;
    try {
      const r = await D.searchDomains(q);
      let items = r.results || [];
      if (activeTld) items = items.filter(i => i.tld === activeTld);
      const all = items.concat(r.suggestions || []);
      const available = all.filter(i => i.available && !i.owned);
      domResults.innerHTML = `<div class="dom-list">
        <div class="dom-head"><span>${items.length} result${items.length === 1 ? '' : 's'} for “${D.esc(q)}”</span><span style="margin-left:auto">${available.length} available of ${all.length}</span></div>
        <div id="rows-a"></div></div>
        ${(r.suggestions || []).length ? `<div class="dom-list" style="margin-top:14px">
          <div class="dom-head"><span>You might also like</span></div><div id="rows-b"></div></div>` : ''}`;
      D.renderDomainList($('#rows-a'), items, buy);
      if (r.suggestions && r.suggestions.length) D.renderDomainList($('#rows-b'), r.suggestions, buy);
    } catch (e) {
      domResults.innerHTML = `<div class="dom-list"><div class="dom-head"><span style="color:var(--err)">${D.esc(e.message)}</span></div></div>`;
    }
  }

  function buy(name, price, premium) {
    D.openCheckout(name, {
      price, premium,
      onDone: () => { if (domQ.value.trim()) runSearch(domQ.value.trim()); },
    });
  }
  // price lookup for a clicked row
  const origRender = D.renderDomainList;
  D.renderDomainList = function (container, items, onBuy) {
    origRender(container, items, (name) => {
      const info = items.find(i => i.name === name);
      buy(name, info ? info.price : 12, info ? info.premium : false);
    });
  };

  $('#dom-search').addEventListener('click', () => { if (domQ.value.trim()) runSearch(domQ.value.trim()); });
  domQ.addEventListener('keydown', (e) => { if (e.key === 'Enter' && domQ.value.trim()) runSearch(domQ.value.trim()); });

  // prefill search from ?q=
  const q0 = new URLSearchParams(location.search).get('q');
  if (q0) { domQ.value = q0; runSearch(q0); }
})();

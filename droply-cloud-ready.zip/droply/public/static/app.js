/* Droply — dashboard */
(function () {
  const D = window.Droply, $ = D.$, esc = D.esc;
  const S = { sites: [], domains: [], orders: [], route: {}, tab: 'deploys' };

  /* ---------------- routing ---------------- */
  function parseHash() {
    const h = (location.hash || '#/overview').replace(/^#\/?/, '');
    const parts = h.split('/');
    if (parts[0] === 'site') return { view: 'site', id: parts[1], tab: parts[2] || null };
    if (parts[0] === 'domains') return { view: 'domains', q: parts[1] ? decodeURIComponent(parts[1]) : '' };
    return { view: ['new', 'domains'].includes(parts[0]) ? parts[0] : 'overview' };
  }
  function go(hash) { location.hash = hash; }

  /* ---------------- data ---------------- */
  async function load() {
    const [st, dm] = await Promise.all([D.api('/api/state'), D.api('/api/domains')]);
    S.sites = st.sites; S.stats = st.stats;
    S.domains = dm.domains; S.orders = dm.orders || [];
  }

  /* ---------------- shared bits ---------------- */
  const ICON = {
    open: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 4h6v6M20 4 10 14M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/></svg>',
    copy: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h8"/></svg>',
    trash: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7h16M9 7V5h6v2M6 7l1 13h10l1-13"/></svg>',
    back: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5l-7 7 7 7"/></svg>',
    plus: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg>',
    up: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 19V5m0 0-6 6m6-6 6 6"/></svg>',
  };

  function copyBtn(url, label) {
    return `<button class="btn sm" data-copy="${esc(url)}">${ICON.copy}${label || 'Copy URL'}</button>`;
  }
  function wireCopy(root) {
    D.$$('[data-copy]', root).forEach(b => b.addEventListener('click', async () => {
      try { await navigator.clipboard.writeText(b.dataset.copy); D.toast('Copied', b.dataset.copy); }
      catch (e) { D.toast('Copy failed', b.dataset.copy, 'err'); }
    }));
  }

  /* ---------------- sidebar ---------------- */
  function renderSide() {
    const el = $('#side-sites');
    if (!S.sites.length) { el.innerHTML = `<div class="hint" style="padding:0 11px">No sites yet</div>`; return; }
    el.innerHTML = S.sites.slice(0, 12).map(s => `
      <div class="site-link" data-site="${s.id}" title="${esc(s.name)}">
        <span class="d"></span><span style="overflow:hidden;text-overflow:ellipsis">${esc(s.name)}</span>
      </div>`).join('');
    D.$$('[data-site]', el).forEach(n => n.addEventListener('click', () => go('#/site/' + n.dataset.site)));

    const bw = (S.stats && S.stats.bytes) || 0;
    $('#q-bw').textContent = D.bytes(bw);
    $('#q-bar').style.width = Math.min(100, (bw / (100 * 1024 ** 3)) * 100).toFixed(3) + '%';
    $('#nav-dom-count').textContent = S.domains.length ? S.domains.length : '';
    D.$$('[data-nav]').forEach(b => b.classList.toggle('active', b.dataset.nav === (S.route.view === 'site' ? 'overview' : S.route.view)));
  }

  /* ---------------- overview ---------------- */
  function viewOverview() {
    const st = S.stats || { sites: 0, deploys: 0, visits: 0, bytes: 0 };
    const v = `
      <div class="topbar">
        <div>
          <h1>Overview</h1>
          <p class="muted">${st.sites} site${st.sites === 1 ? '' : 's'} · ${st.deploys} deploy${st.deploys === 1 ? '' : 's'} · ${D.num(st.visits)} lifetime views</p>
        </div>
        <div class="right">
          <button class="btn primary" data-go="#/new">${ICON.plus}New deploy</button>
        </div>
      </div>

      <div class="stats">
        <div class="stat"><div class="k">Sites</div><div class="v">${D.num(st.sites)}</div></div>
        <div class="stat"><div class="k">Deploys</div><div class="v">${D.num(st.deploys)}</div></div>
        <div class="stat"><div class="k">Views</div><div class="v">${D.num(st.visits)}</div></div>
        <div class="stat"><div class="k">Bandwidth</div><div class="v">${D.bytes(st.bytes)}</div></div>
        <div class="stat"><div class="k">Domains</div><div class="v">${D.num(S.domains.length)}</div></div>
      </div>

      ${S.sites.length ? `<div class="sites">${S.sites.map(siteCard).join('')}</div>` : emptyState()}
    `;
    $('#view').innerHTML = v;
    wireCopy($('#view'));
    D.$$('[data-go]').forEach(b => b.addEventListener('click', () => go(b.dataset.go)));
    D.$$('[data-manage]').forEach(b => b.addEventListener('click', () => go('#/site/' + b.dataset.manage)));
    D.$$('[data-open]').forEach(b => b.addEventListener('click', () => window.open(b.dataset.open, '_blank', 'noopener')));
    D.$$('[data-del]').forEach(b => b.addEventListener('click', () => confirmDelete(b.dataset.del)));
  }

  function siteCard(s) {
    const domain = s.primaryDomain;
    return `<div class="site-card">
      <div class="hd">
        <div style="flex:1;min-width:0">
          <div class="nm" data-manage="${s.id}">${esc(s.name)}</div>
          <div class="url">${esc(domain || s.url.replace(/^https?:\/\//, ''))}</div>
        </div>
        <span class="badge">${s.activeDeploy ? '<span class="p"></span>Published' : 'Draft'}</span>
      </div>
      <div class="meta">
        <span>${s.deployCount} deploy${s.deployCount === 1 ? '' : 's'}</span>
        <span>${D.num(s.visits)} views</span>
        <span>${D.bytes(s.size)}</span>
        <span>${D.timeAgo(s.updatedAt)}</span>
      </div>
      <div class="row-btns">
        <button class="btn sm primary" data-open="${esc(s.url)}">${ICON.open}Open</button>
        ${copyBtn(s.url, 'Copy')}
        <button class="btn sm" data-manage="${s.id}">Manage</button>
        <button class="btn sm danger" data-del="${s.id}">${ICON.trash}</button>
      </div>
    </div>`;
  }

  function emptyState() {
    return `<div class="empty">
      <div class="big">▲</div>
      <h3>Nothing deployed yet</h3>
      <p>Drag a folder with an index.html into the deploy panel, paste some HTML, or import a public GitHub repo.</p>
      <button class="btn primary" data-go="#/new">Create your first deploy</button>
    </div>`;
  }

  /* ---------------- new deploy ---------------- */
  function viewNew() {
    $('#view').innerHTML = `
      <div class="topbar">
        <div><h1>New deploy</h1><p class="muted">Static files only — HTML, CSS, JS, images. Max 40 MB per deploy.</p></div>
        <div class="right"><button class="btn" data-go="#/">Back to overview</button></div>
      </div>

      <div class="panel">
        <div class="panel-hd"><h3>Upload</h3></div>
        <div class="panel-bd">
          <div class="drop" id="dz">
            <div class="icon-wrap"><svg viewBox="0 0 24 24" fill="none" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M12 16V4m0 0L8 8m4-4 4 4"/><path d="M4 15v3a3 3 0 0 0 3 3h10a3 3 0 0 0 3-3v-3"/></svg></div>
            <h3>Drop a folder or .zip here</h3>
            <p>or choose one of the options below</p>
          </div>
          <div class="deploy-actions">
            <button class="btn" id="pick-folder">Choose folder</button>
            <button class="btn" id="pick-files">Choose files</button>
            <button class="btn" id="t-paste">Paste HTML</button>
            <button class="btn" id="t-gh">Import from GitHub</button>
          </div>
          <div id="paste-box" style="display:none;margin-top:16px">
            <textarea class="input" id="paste-html" placeholder="<!doctype html>&#10;<html><body><h1>Hello</h1></body></html>"></textarea>
            <button class="btn primary" id="paste-deploy" style="margin-top:10px">Deploy as index.html</button>
          </div>
          <div id="gh-box" style="display:none;margin-top:16px">
            <div style="display:flex;gap:10px;flex-wrap:wrap">
              <input class="input" id="gh-repo" placeholder="github.com/owner/repo" style="flex:1;min-width:220px">
              <button class="btn primary" id="gh-deploy">Import</button>
            </div>
          </div>
          <div id="dz-progress" style="display:none" class="progress"><i></i></div>
        </div>
      </div>

      <div class="panel">
        <div class="panel-hd"><h3>Destination</h3></div>
        <div class="panel-bd">
          <div class="field">
            <label>Deploy to</label>
            <select class="input" id="dest">
              <option value="">+ Create a new site</option>
              ${S.sites.map(s => `<option value="${s.id}">${esc(s.name)} (${esc(s.slug)})</option>`).join('')}
            </select>
          </div>
          <div id="new-site-fields">
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
              <div class="field"><label>Site name</label><input class="input" id="new-name" placeholder="my-awesome-site"></div>
              <div class="field"><label>URL slug</label><input class="input" id="new-slug" placeholder="auto-generated"><span class="hint">droply.app/s/<b id="slug-preview">…</b>/</span></div>
            </div>
          </div>
          <div class="field" style="margin-bottom:0"><label>Deploy message</label>
            <input class="input" id="msg" placeholder="Manual deploy"></div>
        </div>
      </div>`;

    const root = $('#view');
    D.$$('[data-go]', root).forEach(b => b.addEventListener('click', () => go(b.dataset.go)));

    const bar = $('#dz-progress'), barI = bar.querySelector('i');
    async function ship({ files, name, source, message }) {
      bar.style.display = 'block'; barI.style.width = '15%';
      const dest = $('#dest').value;
      const payload = {
        files,
        name: dest ? undefined : ($('#new-name').value.trim() || name || 'my-site'),
        slug: dest ? undefined : ($('#new-slug').value.trim() || undefined),
        siteId: dest || undefined,
        source, message: $('#msg').value.trim() || message,
      };
      try {
        barI.style.width = '45%';
        const r = await D.api('/api/deploy', { method: 'POST', body: payload });
        barI.style.width = '100%';
        D.toast('Deploy live', r.site.url, 'ok');
        await load(); renderSide();
        go('#/site/' + r.site.id);
      } catch (e) {
        bar.style.display = 'none';
        D.toast('Deploy failed', e.message, 'err');
      }
    }
    async function handleList(list) {
      if (!list.length) return;
      const name = (list[0].path || 'site').split('/')[0].replace(/\.zip$/i, '') || 'site';
      bar.style.display = 'block'; barI.style.width = '8%';
      const { files, skipped } = await D.toPayload(list, p => { barI.style.width = (8 + p * 32).toFixed(0) + '%'; });
      if (!files.length) { bar.style.display = 'none'; return D.toast('Nothing to deploy', 'No readable files found', 'err'); }
      if (skipped) D.toast('Some files skipped', `${skipped} exceeded the 40 MB limit`, 'err');
      await ship({ files, name, source: 'upload', message: 'Manual upload' });
    }

    D.dropzone($('#dz'), { onFiles: handleList });
    $('#dz').addEventListener('click', () => $('#pick-folder').click());

    const folderInput = document.createElement('input');
    folderInput.type = 'file'; folderInput.webkitdirectory = true; folderInput.multiple = true; folderInput.style.display = 'none';
    document.body.appendChild(folderInput);
    folderInput.addEventListener('change', async () => {
      const l = Array.from(folderInput.files).map(f => ({ file: f, path: f.webkitRelativePath || f.name }));
      folderInput.value = ''; await handleList(l);
    });
    $('#pick-folder').addEventListener('click', (e) => { e.stopPropagation(); folderInput.click(); });

    const fileInput = document.createElement('input');
    fileInput.type = 'file'; fileInput.multiple = true; fileInput.style.display = 'none';
    document.body.appendChild(fileInput);
    fileInput.addEventListener('change', async () => {
      const l = Array.from(fileInput.files).map(f => ({ file: f, path: f.name }));
      fileInput.value = ''; await handleList(l);
    });
    $('#pick-files').addEventListener('click', (e) => { e.stopPropagation(); fileInput.click(); });

    $('#t-paste').addEventListener('click', () => {
      const b = $('#paste-box'); b.style.display = b.style.display === 'none' ? 'block' : 'none';
      if (b.style.display === 'block') $('#paste-html').focus();
    });
    $('#paste-deploy').addEventListener('click', async () => {
      const html = $('#paste-html').value.trim();
      if (!html) return D.toast('Nothing to deploy', 'Paste some HTML first', 'err');
      await ship({ files: [{ path: 'index.html', content: html }], name: 'pasted-site', source: 'paste', message: 'Pasted HTML' });
    });

    $('#t-gh').addEventListener('click', () => {
      const b = $('#gh-box'); b.style.display = b.style.display === 'none' ? 'block' : 'none';
      if (b.style.display === 'block') $('#gh-repo').focus();
    });
    $('#gh-deploy').addEventListener('click', async () => {
      const repo = $('#gh-repo').value.trim();
      if (!repo) return D.toast('Repository required', 'Paste a GitHub URL', 'err');
      bar.style.display = 'block'; barI.style.width = '30%';
      try {
        const r = await D.api('/api/import-github', { method: 'POST', body: { repo, name: $('#new-name').value.trim() || undefined } });
        barI.style.width = '100%';
        D.toast('Imported', r.site.url, 'ok');
        await load(); renderSide(); go('#/site/' + r.site.id);
      } catch (e) { bar.style.display = 'none'; D.toast('Import failed', e.message, 'err'); }
    });

    $('#dest').addEventListener('change', () => {
      $('#new-site-fields').style.opacity = $('#dest').value ? '.4' : '1';
    });
    $('#new-name').addEventListener('input', (e) => {
      const s = e.target.value.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
      $('#slug-preview').textContent = s || '…';
    });
  }

  /* ---------------- site detail ---------------- */
  function viewSite() {
    const s = S.sites.find(x => x.id === S.route.id);
    if (!s) { $('#view').innerHTML = `<div class="empty"><h3>Site not found</h3><button class="btn primary" data-go="#/">Back</button></div>`; wire(); return; }
    const tab = S.route.tab || S.tab;
    const domains = S.domains.filter(d => d.siteId === s.id);

    $('#view').innerHTML = `
      <div class="crumb"><a href="#/" data-go="#/">Sites</a> / <span>${esc(s.name)}</span></div>
      <div class="topbar">
        <div>
          <h1>${esc(s.name)}</h1>
          <p class="muted"><a href="${esc(s.url)}" target="_blank" rel="noopener">${esc(s.url.replace(/^https?:\/\//, ''))}</a>
            ${s.primaryDomain ? ` · <a href="https://${esc(s.primaryDomain)}" target="_blank" rel="noopener">${esc(s.primaryDomain)}</a>` : ''}</p>
        </div>
        <div class="right">
          ${copyBtn(s.url, 'Copy URL')}
          <button class="btn" data-open="${esc(s.url)}">${ICON.open}Open</button>
          <button class="btn primary" data-go="#/new">${ICON.up}New deploy</button>
        </div>
      </div>

      <div class="tabs">
        <button data-tab="deploys" class="${tab === 'deploys' ? 'active' : ''}">Deploys</button>
        <button data-tab="analytics" class="${tab === 'analytics' ? 'active' : ''}">Analytics</button>
        <button data-tab="domains" class="${tab === 'domains' ? 'active' : ''}">Domains ${domains.length ? `(${domains.length})` : ''}</button>
        <button data-tab="settings" class="${tab === 'settings' ? 'active' : ''}">Settings</button>
      </div>
      <div id="tab-body"></div>`;
    wire();
    renderTab(s, tab);
    D.$$('[data-tab]').forEach(b => b.addEventListener('click', () => go(`#/site/${s.id}/${b.dataset.tab}`)));

    function wire() {
      wireCopy($('#view'));
      D.$$('[data-go]', $('#view')).forEach(b => b.addEventListener('click', () => go(b.dataset.go)));
      D.$$('[data-open]', $('#view')).forEach(b => b.addEventListener('click', () => window.open(b.dataset.open, '_blank', 'noopener')));
    }
  }

  function renderTab(s, tab) {
    const body = $('#tab-body');
    S.tab = tab;
    if (tab === 'deploys') return renderDeploys(s, body);
    if (tab === 'analytics') return renderAnalytics(s, body);
    if (tab === 'domains') return renderSiteDomains(s, body);
    if (tab === 'settings') return renderSettings(s, body);
  }

  function renderDeploys(s, body) {
    fetch('/api/sites/' + s.id).then(r => r.json()).then(d => {
      const site = d.site;
      body.innerHTML = `
        <div class="panel">
          <div class="panel-hd">
            <h3>Deploy history</h3>
            <span class="hint">${site.deploys.length} deploy${site.deploys.length === 1 ? '' : 's'} · newest first</span>
            <div class="right"><button class="btn sm" data-go="#/new">${ICON.up}New deploy</button></div>
          </div>
          ${site.deploys.map(dep => `
            <div class="deploy-row">
              <span class="id">${dep.id}</span>
              <span class="msg">${esc(dep.message)}</span>
              <span class="sz">${dep.files} files · ${D.bytes(dep.size)}</span>
              <span class="when">${D.timeAgo(dep.createdAt)}</span>
              ${dep.id === site.activeDeploy
                ? `<span class="badge"><span class="p"></span>Production</span>`
                : `<button class="btn sm" data-roll="${dep.id}">Publish</button>`}
              ${dep.id === site.activeDeploy ? '' : `<button class="btn sm danger" data-deldep="${dep.id}">${ICON.trash}</button>`}
            </div>`).join('')}
        </div>
        <p class="hint">Deploys are immutable. Publishing an older one switches production traffic instantly — no rebuild, no downtime.</p>`;

      D.$$('[data-go]', body).forEach(b => b.addEventListener('click', () => go(b.dataset.go)));
      D.$$('[data-roll]', body).forEach(b => b.addEventListener('click', async () => {
        try {
          await D.api(`/api/sites/${s.id}/deploys/${b.dataset.roll}/activate`, { method: 'POST' });
          D.toast('Rolled back', `Deploy ${b.dataset.roll} is now production`, 'ok');
          await load(); renderTab(S.sites.find(x => x.id === s.id), 'deploys'); renderSide();
        } catch (e) { D.toast('Rollback failed', e.message, 'err'); }
      }));
      D.$$('[data-deldep]', body).forEach(b => b.addEventListener('click', async () => {
        try {
          await D.api(`/api/sites/${s.id}/deploys/${b.dataset.deldep}`, { method: 'DELETE' });
          await load(); renderTab(S.sites.find(x => x.id === s.id), 'deploys'); renderSide();
          D.toast('Deploy deleted', b.dataset.deldep, 'ok');
        } catch (e) { D.toast('Delete failed', e.message, 'err'); }
      }));
    });
  }

  function renderAnalytics(s, body) {
    fetch('/api/sites/' + s.id).then(r => r.json()).then(d => {
      const site = d.site;
      const days = site.days || {};
      const keys = [];
      for (let i = 13; i >= 0; i--) {
        const dt = new Date(); dt.setDate(dt.getDate() - i);
        keys.push(dt.toISOString().slice(0, 10));
      }
      const vals = keys.map(k => (days[k] && days[k].v) || 0);
      const uniq = keys.map(k => (days[k] && days[k].u ? days[k].u.length : 0));
      const max = Math.max(1, ...vals);
      const bw14 = keys.reduce((n, k) => n + ((days[k] && days[k].b) || 0), 0);
      const v14 = vals.reduce((a, b) => a + b, 0);

      body.innerHTML = `
        <div class="stats">
          <div class="stat"><div class="k">Views · 14 days</div><div class="v">${D.num(v14)}</div></div>
          <div class="stat"><div class="k">Bandwidth · 14 days</div><div class="v">${D.bytes(bw14)}</div></div>
          <div class="stat"><div class="k">Views · all time</div><div class="v">${D.num(site.visits)}</div></div>
          <div class="stat"><div class="k">Bandwidth · all time</div><div class="v">${D.bytes(site.bytes)}</div></div>
        </div>

        <div class="panel">
          <div class="panel-hd"><h3>Page views, last 14 days</h3><span class="hint">peak ${D.num(max)}/day · ${D.num(uniq.reduce((a, b) => a + b, 0))} uniques</span></div>
          <div class="panel-bd">
            <div class="spark">
              ${vals.map((v, i) => `<div class="col" style="height:${Math.max(3, (v / max) * 96)}px" data-l="${keys[i]} · ${v} view${v === 1 ? '' : 's'}"></div>`).join('')}
            </div>
            <div class="spark-axis"><span>${keys[0]}</span><span>today</span></div>
          </div>
        </div>

        <div class="panel">
          <div class="panel-hd"><h3>Top pages</h3></div>
          <table class="tbl">
            <thead><tr><th>Path</th><th style="text-align:right">Views</th></tr></thead>
            <tbody>
              ${(site.paths && site.paths.length) ? site.paths.map(p => `<tr><td class="mono">${esc(p.path)}</td><td>${D.num(p.count)}</td></tr>`).join('')
                : `<tr><td colspan="2" class="hint">No page views recorded yet. Visit <a href="${esc(site.url)}" target="_blank" rel="noopener">your site</a> and refresh this tab.</td></tr>`}
            </tbody>
          </table>
        </div>`;
    });
  }

  function renderSiteDomains(s, body) {
    const mine = S.domains.filter(d => d.siteId === s.id);
    const unattached = S.domains.filter(d => !d.siteId);

    body.innerHTML = `
      ${mine.length ? `<div class="sites" style="margin-bottom:18px">${mine.map(d => `
        <div class="dom-card">
          <div class="nm">${esc(d.name)} ${d.ssl && d.ssl.status === 'issued' ? '<span class="ssl-badge">SSL demo</span>' : ''}</div>
          <div class="meta">
            <span>Demo expiry ${D.dateStr(d.expiresAt)}</span>
            <span>${D.money(d.price)}/yr${d.premium ? ' (premium)' : ''}</span>
            <span>Demo auto-renew ${d.autoRenew ? 'on' : 'off'}</span>
          </div>
          <div class="hint">Demo record only: this prototype does not register the domain, change DNS, or issue TLS. Configure real DNS with your registrar and hosting provider.</div>
          <div class="row-btns">
            <button class="btn sm" data-detach="${d.id}">Detach from site</button>
            <button class="btn sm" data-renew="${d.id}">Simulate renewal 1 yr</button>
            <button class="btn sm danger" data-domdel="${d.id}">${ICON.trash}</button>
          </div>
        </div>`).join('')}</div>` : `<div class="panel"><div class="panel-bd"><div class="hint">No demo domain is connected yet. The in-app checkout does not create a real registration.</div></div></div>`}

      ${unattached.length ? `<div class="panel" style="margin-bottom:18px">
        <div class="panel-hd"><h3>Attach a demo domain record</h3></div>
        <div class="panel-bd">
          ${unattached.map(d => `<div class="deploy-row">
            <span class="id">${esc(d.name)}</span><span class="msg">Demo record created ${D.dateStr(d.purchasedAt)}</span>
            <button class="btn sm" data-attach="${d.id}">Attach to this site</button>
          </div>`).join('')}
        </div>
      </div>` : ''}

      <div class="panel">
        <div class="panel-hd"><h3>Try domain checkout for ${esc(s.name)}</h3></div>
        <div class="panel-bd">
          <div class="dom-search">
            <input class="input" id="sd-q" placeholder="Search sample names, e.g. yourname.com" autocomplete="off">
            <button class="btn primary" id="sd-search">Search</button>
          </div>
          <div id="sd-results"></div>
        </div>
      </div>`;

    const run = async () => {
      const q = $('#sd-q').value.trim();
      if (!q) return;
      const box = $('#sd-results');
      box.innerHTML = `<div class="hint">Checking…</div>`;
      try {
        const r = await D.searchDomains(q);
        box.innerHTML = `<div class="dom-list"><div class="dom-head"><span>Results for “${esc(q)}”</span></div><div id="sd-rows"></div></div>
          ${(r.suggestions || []).length ? `<div class="dom-list" style="margin-top:14px"><div class="dom-head"><span>Suggestions</span></div><div id="sd-rows2"></div></div>` : ''}`;
        const render = (id, items) => {
          D.renderDomainList($(id), items, (name) => {
            const info = items.find(i => i.name === name);
            D.openCheckout(name, {
              price: info ? info.price : 12, premium: info ? info.premium : false,
              onDone: async () => { await load(); renderSide(); renderSiteDomains(S.sites.find(x => x.id === s.id), body); },
            });
          });
        };
        render('#sd-rows', r.results || []);
        if (r.suggestions && r.suggestions.length) render('#sd-rows2', r.suggestions);
      } catch (e) { box.innerHTML = `<div class="hint" style="color:var(--err)">${esc(e.message)}</div>`; }
    };
    $('#sd-search').addEventListener('click', run);
    $('#sd-q').addEventListener('keydown', e => { if (e.key === 'Enter') run(); });

    D.$$('[data-attach]', body).forEach(b => b.addEventListener('click', async () => {
      try {
        await D.api(`/api/domains/${b.dataset.attach}/attach`, { method: 'POST', body: { siteId: s.id } });
        D.toast('Demo domain attached', 'No DNS or TLS changes were made', 'ok');
        await load(); renderSide(); renderSiteDomains(S.sites.find(x => x.id === s.id), body);
      } catch (e) { D.toast('Failed', e.message, 'err'); }
    }));
    D.$$('[data-detach]', body).forEach(b => b.addEventListener('click', async () => {
      try {
        await D.api(`/api/domains/${b.dataset.detach}/detach`, { method: 'POST' });
        D.toast('Detached', 'The domain is now unassigned', 'ok');
        await load(); renderSide(); renderSiteDomains(S.sites.find(x => x.id === s.id), body);
      } catch (e) { D.toast('Failed', e.message, 'err'); }
    }));
    D.$$('[data-renew]', body).forEach(b => b.addEventListener('click', async () => {
      try {
        const r = await D.api(`/api/domains/${b.dataset.renew}/renew`, { method: 'POST' });
        D.toast('Demo renewal saved', `${r.domain.name} — no charge was made`, 'ok');
        await load(); renderSiteDomains(S.sites.find(x => x.id === s.id), body);
      } catch (e) { D.toast('Renewal failed', e.message, 'err'); }
    }));
    D.$$('[data-domdel]', body).forEach(b => b.addEventListener('click', async () => {
      const d = S.domains.find(x => x.id === b.dataset.domdel);
      if (!confirm(`Delete ${d.name}? This cannot be undone.`)) return;
      try {
        await D.api('/api/domains/' + b.dataset.domdel, { method: 'DELETE' });
        await load(); renderSide(); renderSiteDomains(S.sites.find(x => x.id === s.id), body);
        D.toast('Domain removed', d.name, 'ok');
      } catch (e) { D.toast('Failed', e.message, 'err'); }
    }));
  }

  function renderSettings(s, body) {
    body.innerHTML = `
      <div class="panel">
        <div class="panel-hd"><h3>Site settings</h3></div>
        <div class="panel-bd">
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
            <div class="field"><label>Site name</label><input class="input" id="set-name" value="${esc(s.name)}"></div>
            <div class="field"><label>URL slug</label><input class="input" id="set-slug" value="${esc(s.slug)}">
              <span class="hint">Your site will move to <b>/s/${esc(s.slug)}/</b></span></div>
          </div>
          <button class="btn primary" id="set-save">Save changes</button>
        </div>
      </div>

      <div class="panel">
        <div class="panel-hd"><h3>Production URL</h3></div>
        <div class="panel-bd">
          <div class="mono" style="font-size:14px">${esc(s.url)}</div>
          <div class="hint">Sites are served from this host. Point a purchased domain here with a CNAME to serve the same content at your own address.</div>
        </div>
      </div>

      <div class="panel" style="border-color:rgba(255,107,107,.35)">
        <div class="panel-hd"><h3 style="color:var(--err)">Danger zone</h3></div>
        <div class="panel-bd">
          <p class="hint" style="margin-top:0">Deleting <b>${esc(s.name)}</b> removes all ${s.deployCount} deploy(s) and its files. Analytics go with it.</p>
          <button class="btn danger" id="set-del">${ICON.trash}Delete this site</button>
        </div>
      </div>`;

    $('#set-save').addEventListener('click', async () => {
      try {
        const r = await D.api(`/api/sites/${s.id}`, {
          method: 'PATCH',
          body: { name: $('#set-name').value.trim(), slug: $('#set-slug').value.trim() },
        });
        D.toast('Saved', r.site.url, 'ok');
        await load(); renderSide(); viewSite();
      } catch (e) { D.toast('Save failed', e.message, 'err'); }
    });
    $('#set-del').addEventListener('click', () => confirmDelete(s.id));
  }

  /* ---------------- domains view ---------------- */
  function viewDomains() {
    const q = S.route.q || '';
    const unattached = S.domains.filter(d => !d.siteId);
    $('#view').innerHTML = `
      <div class="topbar">
        <div><h1>Domains</h1><p class="muted">${S.domains.length} simulated record${S.domains.length === 1 ? '' : 's'} · no real registrations</p></div>
        <div class="right"><button class="btn" data-go="#/">Back to overview</button></div>
      </div>

      <div class="panel">
        <div class="panel-hd"><h3>Find a domain (demo)</h3></div>
        <div class="panel-bd">
          <div class="dom-search">
            <input class="input" id="d-q" placeholder="Search for your next domain" value="${esc(q)}" autocomplete="off">
            <button class="btn primary" id="d-search">Search</button>
          </div>
          <div id="d-results"></div>
        </div>
      </div>

      <div class="panel">
        <div class="panel-hd"><h3>Demo domain records</h3><span class="hint">No registration, DNS, or payment</span></div>
        <div class="panel-bd">
          ${S.domains.length ? `<div class="sites">${S.domains.map(d => {
            const site = S.sites.find(s => s.id === d.siteId);
            return `<div class="dom-card ${d.siteId ? '' : 'dangling'}">
              <div class="nm">${esc(d.name)} ${d.ssl && d.ssl.status === 'issued' ? '<span class="ssl-badge">SSL demo</span>' : ''}</div>
              <div class="meta">
                <span>${site ? '→ ' + esc(site.name) : 'Not connected'}</span>
                <span>Demo expiry ${D.dateStr(d.expiresAt)}</span>
                <span>${D.money(d.price)}/yr${d.premium ? ' premium' : ''}</span>
              </div>
              <div class="receipt">Demo record created ${D.dateStr(d.purchasedAt)} · ${d.years} yr term</div>
              <div class="row-btns">
                ${site ? `<button class="btn sm" data-open="${esc(site.url)}">${ICON.open}Visit</button>` : `<button class="btn sm" data-go="#/">Attach to a site</button>`}
                <button class="btn sm" data-ar="${d.id}">Toggle demo auto-renew</button>
                <button class="btn sm danger" data-domdel="${d.id}">${ICON.trash}</button>
              </div>
            </div>`;
          }).join('')}</div>` : `<div class="empty" style="padding:34px"><div class="big">◎</div><h3>No demo records yet</h3><p>Search above for sample availability and pricing; real registration is not enabled.</p></div>`}
        </div>
      </div>

      ${S.orders.length ? `<div class="panel">
        <div class="panel-hd"><h3>Demo receipts</h3></div>
        <table class="tbl">
          <thead><tr><th>Order</th><th>Domain</th><th>Card</th><th style="text-align:right">Total</th></tr></thead>
          <tbody>${S.orders.slice(0, 10).map(o => `<tr>
            <td class="mono">${esc(o.id)}</td><td>${esc(o.domain)}</td>
            <td>${o.card ? esc(o.card.brand) + ' •••• ' + esc(o.card.last4) : '—'}</td>
            <td>${D.money(o.total)}</td></tr>`).join('')}</tbody>
        </table>
      </div>` : ''}`;

    const run = async () => {
      const query = $('#d-q').value.trim();
      if (!query) return;
      const box = $('#d-results');
      box.innerHTML = `<div class="hint">Checking demo availability…</div>`;
      try {
        const r = await D.searchDomains(query);
        box.innerHTML = `<div class="dom-list"><div class="dom-head"><span>Results</span></div><div id="d-rows"></div></div>
          ${(r.suggestions || []).length ? `<div class="dom-list" style="margin-top:14px"><div class="dom-head"><span>Suggestions</span></div><div id="d-rows2"></div></div>` : ''}`;
        const render = (id, items) => D.renderDomainList($(id), items, (name) => {
          const info = items.find(i => i.name === name);
          D.openCheckout(name, {
            price: info ? info.price : 12, premium: info ? info.premium : false,
            onDone: async () => { await load(); renderSide(); viewDomains(); },
          });
        });
        render('#d-rows', r.results || []);
        if (r.suggestions && r.suggestions.length) render('#d-rows2', r.suggestions);
      } catch (e) { box.innerHTML = `<div class="hint" style="color:var(--err)">${esc(e.message)}</div>`; }
    };
    $('#d-search').addEventListener('click', run);
    $('#d-q').addEventListener('keydown', e => { if (e.key === 'Enter') run(); });
    if (q) run();

    D.$$('[data-go]', $('#view')).forEach(b => b.addEventListener('click', () => go(b.dataset.go)));
    D.$$('[data-open]', $('#view')).forEach(b => b.addEventListener('click', () => window.open(b.dataset.open, '_blank', 'noopener')));
    D.$$('[data-ar]', $('#view')).forEach(b => b.addEventListener('click', async () => {
      const d = S.domains.find(x => x.id === b.dataset.ar);
      try {
        await D.api(`/api/domains/${d.id}/autorenew`, { method: 'PATCH', body: { autoRenew: !d.autoRenew } });
        await load(); viewDomains();
      } catch (e) { D.toast('Failed', e.message, 'err'); }
    }));
    D.$$('[data-domdel]', $('#view')).forEach(b => b.addEventListener('click', async () => {
      const d = S.domains.find(x => x.id === b.dataset.domdel);
      if (!confirm(`Delete ${d.name}? This cannot be undone.`)) return;
      try {
        await D.api('/api/domains/' + d.id, { method: 'DELETE' });
        await load(); renderSide(); viewDomains();
        D.toast('Domain removed', d.name, 'ok');
      } catch (e) { D.toast('Failed', e.message, 'err'); }
    }));
  }

  /* ---------------- delete confirmation ---------------- */
  function confirmDelete(id) {
    const s = S.sites.find(x => x.id === id);
    if (!s) return;
    const back = document.createElement('div');
    back.className = 'modal-back';
    back.innerHTML = `<div class="modal">
      <h3>Delete ${esc(s.name)}?</h3>
      <p>This permanently removes ${s.deployCount} deploy(s), all uploaded files, and its analytics. Custom domains stay in your account.</p>
      <div class="acts">
        <button class="btn ghost" id="c-no">Cancel</button>
        <button class="btn danger" id="c-yes">Delete site</button>
      </div>
    </div>`;
    document.body.appendChild(back);
    const close = () => back.remove();
    $('#c-no', back).addEventListener('click', close);
    back.addEventListener('click', e => { if (e.target === back) close(); });
    $('#c-yes', back).addEventListener('click', async () => {
      close();
      try {
        await D.api('/api/sites/' + id, { method: 'DELETE' });
        D.toast('Site deleted', s.name, 'ok');
        await load(); renderSide(); go('#/');
      } catch (e) { D.toast('Delete failed', e.message, 'err'); }
    });
  }

  /* ---------------- boot ---------------- */
  async function render() {
    S.route = parseHash();
    const v = $('#view');
    if (S.route.view === 'site') viewSite();
    else if (S.route.view === 'new') viewNew();
    else if (S.route.view === 'domains') viewDomains();
    else viewOverview();
    renderSide();
  }

  window.addEventListener('hashchange', render);
  (async () => {
    try { await load(); } catch (e) { D.toast('Could not reach the API', e.message, 'err'); }
    render();
  })();
})();

'use strict';
/**
 * Droply — free static site hosting (a Netlify-style platform).
 * Zero dependencies. Node 18+.
 *
 *   /                 -> marketing site
 *   /dashboard        -> app dashboard
 *   /s/<slug>/...     -> a published site
 *   /api/...          -> JSON API
 */

const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const crypto = require('crypto');

const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, 'public');
// Set DATA_DIR to a mounted persistent volume in production. Railway also
// provides RAILWAY_VOLUME_MOUNT_PATH automatically when a volume is attached.
const DATA_DIR = path.resolve(process.env.DATA_DIR || process.env.RAILWAY_VOLUME_MOUNT_PATH || path.join(ROOT, 'data'));
const SITES_DIR = path.join(DATA_DIR, 'sites');
const STORE_FILE = path.join(DATA_DIR, 'store.json');

const PORT = Number(process.env.PORT || 3000);
const HOST = '0.0.0.0';
// Optional wildcard base for Netlify-style per-site hostnames, e.g. sites.example.com.
// Point *.sites.example.com at this service before enabling it.
let SITES_DOMAIN = String(process.env.DROPLY_SITES_DOMAIN || '').trim().toLowerCase();
while (SITES_DOMAIN.startsWith('.')) SITES_DOMAIN = SITES_DOMAIN.slice(1);
while (SITES_DOMAIN.endsWith('.')) SITES_DOMAIN = SITES_DOMAIN.slice(0, -1);
const MAX_BODY = 80 * 1024 * 1024;   // request body cap
const MAX_FILES = 3000;              // files per deploy
const MAX_TOTAL = 60 * 1024 * 1024;  // bytes per deploy

fs.mkdirSync(SITES_DIR, { recursive: true });

/* ------------------------------------------------------------------ *
 * Store
 * ------------------------------------------------------------------ */

let store = loadStore();

function loadStore() {
  try {
    const s = JSON.parse(fs.readFileSync(STORE_FILE, 'utf8'));
    if (!Array.isArray(s.sites)) s.sites = [];
    if (!Array.isArray(s.domains)) s.domains = [];
    if (!Array.isArray(s.orders)) s.orders = [];
    return s;
  } catch (e) {
    return { createdAt: Date.now(), sites: [], domains: [], orders: [] };
  }
}

let saveTimer = null;
function saveNow() {
  if (saveTimer) { clearTimeout(saveTimer); saveTimer = null; }
  try {
    const tmp = STORE_FILE + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(store));
    fs.renameSync(tmp, STORE_FILE);
  } catch (e) {
    console.error('save failed:', e.message);
  }
}
function save() {
  if (saveTimer) return;
  saveTimer = setTimeout(() => { saveTimer = null; saveNow(); }, 400);
}

/* ------------------------------------------------------------------ *
 * Helpers
 * ------------------------------------------------------------------ */

const MIME = {
  '.html': 'text/html; charset=utf-8', '.htm': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.js': 'application/javascript; charset=utf-8',
  '.mjs': 'application/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
  '.gif': 'image/gif', '.webp': 'image/webp', '.avif': 'image/avif', '.ico': 'image/x-icon',
  '.woff': 'font/woff', '.woff2': 'font/woff2', '.ttf': 'font/ttf', '.otf': 'font/otf',
  '.mp4': 'video/mp4', '.webm': 'video/webm', '.mp3': 'audio/mpeg', '.wav': 'audio/wav',
  '.pdf': 'application/pdf', '.txt': 'text/plain; charset=utf-8',
  '.md': 'text/markdown; charset=utf-8', '.xml': 'application/xml; charset=utf-8',
  '.map': 'application/json; charset=utf-8', '.wasm': 'application/wasm',
};
const mimeFor = (f) => MIME[path.extname(f).toLowerCase()] || 'application/octet-stream';

const ADJ = ['swift', 'cosmic', 'lucky', 'velvet', 'quiet', 'brave', 'lucid', 'amber', 'crimson', 'noble',
  'rapid', 'silent', 'solar', 'violet', 'zesty', 'copper', 'mellow', 'frosty', 'bold', 'minty'];
const NOUN = ['panda', 'comet', 'otter', 'falcon', 'meadow', 'lantern', 'harbor', 'cactus', 'pixel',
  'nebula', 'willow', 'badger', 'coral', 'dolphin', 'ember', 'glacier', 'quartz', 'sparrow', 'tiger', 'orbit'];
const pick = (a) => a[Math.floor(Math.random() * a.length)];

function randId(bytes = 5) { return crypto.randomBytes(bytes).toString('hex'); }
function randName() { return `${pick(ADJ)}-${pick(NOUN)}`; }

const RESERVED = new Set(['api', 's', 'dashboard', 'app', 'admin', 'static', 'assets', 'login', 'signup',
  'docs', 'blog', 'pricing', 'status', 'settings', 'new', 'site', 'sites', 'help', 'about', '_', 'favicon.ico',
  'robots.txt', 'manifest.json', 'index.html']);

function slugify(input) {
  let s = String(input || '').toLowerCase()
    .normalize('NFKD').replace(/[\u0300-\u036f]/g, '') // combining marks
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 48).replace(/-+$/g, '');
  if (!s || s.length < 3 || RESERVED.has(s)) s = randName() + '-' + randId(2);
  return s;
}
function uniqueSlug(want) {
  let base = slugify(want);
  let slug = base, i = 2;
  const taken = new Set(store.sites.map(s => s.slug));
  while (taken.has(slug)) slug = `${base}-${i++}`;
  return slug;
}

// Reject traversal, absolute paths, and junk.
function sanitizePath(p) {
  if (!p) return null;
  let s = String(p).replace(/\\/g, '/');
  s = s.split('?')[0].split('#')[0];
  const parts = [];
  for (const seg of s.split('/')) {
    if (!seg || seg === '.' ) continue;
    if (seg === '..') return null;
    if (/[\u0000-\u001f]/.test(seg)) return null;
    parts.push(seg.replace(/[<>:"|*]/g, '_'));
  }
  if (!parts.length) return null;
  const joined = parts.join('/');
  if (joined.length > 240) return null;
  return joined;
}

function publicUrl(req, slug) {
  if (SITES_DOMAIN) return `https://${slug}.${SITES_DOMAIN}/`;
  const host = (req.headers['x-forwarded-host'] || req.headers.host || `localhost:${PORT}`).split(',')[0].trim();
  const proto = (req.headers['x-forwarded-proto'] || 'http').split(',')[0].trim();
  return `${proto}://${host}/s/${slug}/`;
}

function hostnameFromRequest(req) {
  const raw = (req.headers['x-forwarded-host'] || req.headers.host || '').split(',')[0].trim().toLowerCase();
  if (raw.startsWith('[')) {
    const end = raw.indexOf(']');
    return end > 0 ? raw.slice(1, end) : raw;
  }
  return raw.replace(/:[0-9]+$/, '');
}

function siteSlugFromHost(host) {
  if (!SITES_DOMAIN) return null;
  const suffix = '.' + SITES_DOMAIN;
  if (!host.endsWith(suffix)) return null;
  const slug = host.slice(0, -suffix.length);
  if (!slug || slug.includes('.') || !/^[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/.test(slug)) return null;
  return slug;
}

function siteView(site, req) {
  const active = site.deploys.find(d => d.id === site.activeDeploy) || site.deploys[0] || null;
  return {
    id: site.id,
    name: site.name,
    slug: site.slug,
    createdAt: site.createdAt,
    updatedAt: site.updatedAt,
    visits: site.visits || 0,
    bytes: site.bytes || 0,
    days: site.days || {},
    paths: topPaths(site),
    domains: store.domains
      .filter(d => d.siteId === site.id)
      .map(d => ({ name: d.name, primary: site.primaryDomain === d.name, status: d.status, expiresAt: d.expiresAt })),
    primaryDomain: site.primaryDomain || null,
    activeDeploy: active ? active.id : null,
    deployCount: site.deploys.length,
    files: active ? active.files : 0,
    size: active ? active.size : 0,
    url: publicUrl(req, site.slug),
  };
}
function topPaths(site) {
  const p = site.paths || {};
  return Object.entries(p).map(([path, count]) => ({ path, count }))
    .sort((a, b) => b.count - a.count).slice(0, 8);
}

function readBody(req, limit = MAX_BODY) {
  return new Promise((resolve, reject) => {
    const chunks = []; let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) { reject(new Error('Payload too large (limit ' + Math.round(limit / 1048576) + 'MB)')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

function sendJson(res, code, obj) {
  const b = Buffer.from(JSON.stringify(obj));
  res.writeHead(code, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': b.length,
    'cache-control': 'no-store',
  });
  res.end(b);
}

/* ------------------------------------------------------------------ *
 * ZIP reading (stored + deflate), no dependencies
 * ------------------------------------------------------------------ */

function findBytes(buf, sig, from) {
  const s = Buffer.from(sig);
  let i = buf.indexOf(s, from);
  return i;
}

function unzip(buf) {
  let eocd = -1;
  const min = Math.max(0, buf.length - 22 - 65535);
  for (let i = buf.length - 22; i >= min; i--) {
    if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd < 0) throw new Error('Not a valid ZIP archive (no end-of-central-directory record)');

  const count = buf.readUInt16LE(eocd + 10);
  let off = buf.readUInt32LE(eocd + 16);
  const out = [];

  for (let i = 0; i < count; i++) {
    if (off + 46 > buf.length || buf.readUInt32LE(off) !== 0x02014b50) break;
    const flags = buf.readUInt16LE(off + 8);
    const method = buf.readUInt16LE(off + 10);
    let compSize = buf.readUInt32LE(off + 20);
    const uncSize = buf.readUInt32LE(off + 24);
    const nameLen = buf.readUInt16LE(off + 28);
    const extraLen = buf.readUInt16LE(off + 30);
    const commentLen = buf.readUInt16LE(off + 32);
    const localOff = buf.readUInt32LE(off + 42);
    const name = buf.slice(off + 46, off + 46 + nameLen).toString('utf8');
    off += 46 + nameLen + extraLen + commentLen;

    if (/\/$/.test(name)) continue; // directory entry

    if (buf.readUInt32LE(localOff) !== 0x04034b50) continue;
    const lNameLen = buf.readUInt16LE(localOff + 26);
    const lExtraLen = buf.readUInt16LE(localOff + 28);
    let dataStart = localOff + 30 + lNameLen + lExtraLen;
    let size = compSize;

    if ((flags & 8) !== 0 && compSize === 0) {
      // Sizes live in a trailing data descriptor.
      let dd = findBytes(buf, [0x50, 0x4b, 0x07, 0x08], dataStart);
      while (dd >= 0 && dd + 16 <= buf.length) {
        const cs = buf.readUInt32LE(dd + 8);
        const us = buf.readUInt32LE(dd + 12);
        // sanity: descriptor should sit right after data; accept plausible pair
        if (cs > 0 && us >= cs && cs < buf.length) { size = cs; break; }
        dd = findBytes(buf, [0x50, 0x4b, 0x07, 0x08], dd + 1);
      }
      if (size === 0) continue;
    }

    const data = buf.slice(dataStart, dataStart + size);
    if (data.length === 0) continue;
    let content;
    try {
      if (method === 0) content = data;
      else if (method === 8) content = zlib.inflateRawSync(data);
      else continue; // unsupported compression
    } catch (e) { continue; }

    const clean = sanitizePath(name);
    if (!clean) continue;
    // Skip macOS metadata junk
    if (/(^|\/)__MACOSX\//.test(clean) || /(^|\/)\.DS_Store$/.test(clean)) continue;
    out.push({ path: clean, buf: content });
  }
  if (!out.length) throw new Error('ZIP archive is empty or unreadable');
  return out;
}

// If every entry shares one top-level folder (repo-main/, dist/ …), drop it.
function stripCommonRoot(entries) {
  if (!entries.length) return entries;
  const first = entries[0].path.split('/');
  if (first.length < 2) return entries;
  const root = first[0];
  if (!entries.every(e => e.path === root || e.path.startsWith(root + '/'))) return entries;
  return entries
    .map(e => ({ ...e, path: e.path === root ? e.path : e.path.slice(root.length + 1) }))
    .filter(e => e.path);
}

/* ------------------------------------------------------------------ *
 * Deploys
 * ------------------------------------------------------------------ */

function expandArchives(files) {
  // A single .zip upload is treated as an archive, not a file to serve.
  if (files.length !== 1) return files;
  const f = files[0];
  if (!/\.zip$/i.test(f.path || '')) return files;
  let buf;
  try { buf = Buffer.from(f.b64 || '', 'base64'); } catch (e) { return files; }
  if (buf.length < 4) return files;
  try {
    const entries = unzip(buf);
    const stripped = stripCommonRoot(entries);
    return stripped.map(e => ({ path: e.path, b64: e.buf.toString('base64') }));
  } catch (e) {
    throw Object.assign(new Error('Could not read that ZIP file: ' + e.message), { code: 400 });
  }
}

function writeDeploy(siteId, files, message) {
  files = expandArchives(files);
  const deployId = randId(5);
  const dir = path.join(SITES_DIR, siteId, deployId);
  fs.mkdirSync(dir, { recursive: true });
  let size = 0, written = 0;
  for (const f of files) {
    if (written >= MAX_FILES) break;
    const rel = sanitizePath(f.path);
    if (!rel) continue;
    const target = path.join(dir, rel);
    if (!path.dirname(target).startsWith(dir)) continue;
    let buf;
    if (f.b64) buf = Buffer.from(f.b64, 'base64');
    else buf = Buffer.from(f.content == null ? '' : String(f.content), 'utf8');
    size += buf.length;
    if (size > MAX_TOTAL) break;
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.writeFileSync(target, buf);
    written++;
  }
  return { id: deployId, dir, files: written, size };
}

function deleteDeployDir(siteId, deployId) {
  fs.rmSync(path.join(SITES_DIR, siteId, deployId), { recursive: true, force: true });
}

function createSite({ name, slug, files, message, source }) {
  const id = randId(6);
  const site = {
    id,
    name: String(name || 'my-site').slice(0, 60),
    slug: uniqueSlug(slug || name),
    createdAt: Date.now(),
    updatedAt: Date.now(),
    visits: 0,
    bytes: 0,
    days: {},
    paths: {},
    deploys: [],
    activeDeploy: null,
  };
  const dep = writeDeploy(id, files, message);
  site.deploys.unshift({
    id: dep.id, createdAt: Date.now(), files: dep.files, size: dep.size,
    message: message || 'Initial deploy', source: source || 'upload', visits: 0,
  });
  site.activeDeploy = dep.id;
  store.sites.unshift(site);
  save();
  return site;
}

function addDeploy(site, { files, message, source }) {
  const dep = writeDeploy(site.id, files, message);
  site.deploys.unshift({
    id: dep.id, createdAt: Date.now(), files: dep.files, size: dep.size,
    message: message || 'New deploy', source: source || 'upload', visits: 0,
  });
  site.updatedAt = Date.now();
  // keep the 20 most recent deploys on disk
  const keep = site.deploys.slice(0, 20);
  for (const old of site.deploys.slice(20)) deleteDeployDir(site.id, old.id);
  site.deploys = keep;
  save();
  return site.deploys[0];
}

function findSite(idOrSlug) {
  return store.sites.find(s => s.id === idOrSlug || s.slug === idOrSlug);
}

/* ------------------------------------------------------------------ *
 * Analytics
 * ------------------------------------------------------------------ */

function recordHit(site, urlPath, bytes, req) {
  const day = new Date().toISOString().slice(0, 10);
  site.visits = (site.visits || 0) + 1;
  site.bytes = (site.bytes || 0) + bytes;
  const d = site.days[day] || (site.days[day] = { v: 0, b: 0, u: [] });
  d.v += 1; d.b += bytes;
  const ip = (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || req.socket.remoteAddress || 'local';
  const vh = crypto.createHash('sha1').update(ip + (req.headers['user-agent'] || '')).digest('hex').slice(0, 10);
  if (!d.u.includes(vh) && d.u.length < 500) d.u.push(vh);
  if (/\.(html?|\/)$/.test(urlPath) || urlPath === '/' || !/\.[a-z0-9]{2,5}$/i.test(urlPath)) {
    site.paths[urlPath] = (site.paths[urlPath] || 0) + 1;
  }
  const active = site.deploys.find(x => x.id === site.activeDeploy);
  if (active) active.visits = (active.visits || 0) + 1;
  save();
}

/* ------------------------------------------------------------------ *
 * Published-site server
 * ------------------------------------------------------------------ */

function servePublished(req, res, slug, urlPath) {
  const site = store.sites.find(s => s.slug === slug);
  if (!site) return notFoundApp(req, res, `No site is published at <b>/s/${slug}</b>.`);

  const dep = site.deploys.find(d => d.id === site.activeDeploy) || site.deploys[0];
  if (!dep) return notFoundApp(req, res, 'This site has no deploys yet.');

  const base = path.join(SITES_DIR, site.id, dep.id);
  let rel = sanitizePath(urlPath);
  if (!rel) rel = 'index.html';

  const candidates = [];
  const stat = (p) => { try { return fs.statSync(p); } catch (e) { return null; } };

  if (rel.endsWith('/')) candidates.push(path.join(base, rel, 'index.html'));
  else {
    candidates.push(path.join(base, rel));
    candidates.push(path.join(base, rel, 'index.html'));
    candidates.push(path.join(base, rel + '.html'));
  }

  let file = null, st = null;
  for (const c of candidates) {
    if (!c.startsWith(base)) continue;
    const s = stat(c);
    if (s && s.isFile()) { file = c; st = s; break; }
  }

  if (!file) {
    const custom404 = path.join(base, '404.html');
    const s404 = stat(custom404);
    if (s404 && s404.isFile()) {
      const buf = fs.readFileSync(custom404);
      recordHit(site, urlPath, buf.length, req);
      res.writeHead(404, { 'content-type': 'text/html; charset=utf-8', 'content-length': buf.length, 'cache-control': 'no-cache' });
      return res.end(req.method === 'HEAD' ? undefined : buf);
    }
    return notFoundApp(req, res, `The page <b>/${rel}</b> could not be found on <b>${site.name}</b>.`, 404);
  }

  const buf = fs.readFileSync(file);
  recordHit(site, urlPath, buf.length, req);
  const hash = crypto.createHash('md5').update(buf).digest('hex').slice(0, 16);
  const isHashed = /\.[0-9a-f]{8,}\./i.test(file);
  res.writeHead(200, {
    'content-type': mimeFor(file),
    'content-length': buf.length,
    'etag': '"' + hash + '"',
    'cache-control': isHashed ? 'public, max-age=31536000, immutable' : 'public, max-age=0, must-revalidate',
    'x-droply-site': site.slug,
    'x-droply-deploy': dep.id,
  });
  res.end(req.method === 'HEAD' ? undefined : buf);
}

/* ------------------------------------------------------------------ *
 * App static files
 * ------------------------------------------------------------------ */

const APP_FILES = {
  '/': { file: 'index.html', type: 'text/html; charset=utf-8' },
  '/index.html': { file: 'index.html', type: 'text/html; charset=utf-8' },
  '/dashboard': { file: 'dashboard.html', type: 'text/html; charset=utf-8' },
  '/docs': { file: 'docs.html', type: 'text/html; charset=utf-8' },
  '/favicon.svg': { file: 'favicon.svg', type: 'image/svg+xml' },
  '/robots.txt': { file: null, type: 'text/plain' },
};

function serveAppFile(req, res, urlPath) {
  const entry = APP_FILES[urlPath];
  if (!entry) return serveStaticAsset(req, res, urlPath);

  if (urlPath === '/robots.txt') {
    const b = Buffer.from('User-agent: *\nAllow: /\nDisallow: /dashboard\nDisallow: /api\n');
    res.writeHead(200, { 'content-type': 'text/plain; charset=utf-8', 'content-length': b.length });
    return res.end(req.method === 'HEAD' ? undefined : b);
  }
  const p = path.join(PUBLIC_DIR, entry.file);
  fs.readFile(p, (err, buf) => {
    if (err) return notFoundApp(req, res, 'Page not found.');
    res.writeHead(200, { 'content-type': entry.type, 'content-length': buf.length, 'cache-control': 'no-cache' });
    res.end(req.method === 'HEAD' ? undefined : buf);
  });
}

function serveStaticAsset(req, res, urlPath) {
  const rel = sanitizePath(urlPath.replace(/^\/+/, ''));
  if (!rel || !rel.startsWith('static/')) return notFoundApp(req, res, 'Not found.');
  const p = path.join(PUBLIC_DIR, rel);
  if (!p.startsWith(PUBLIC_DIR)) return notFoundApp(req, res, 'Not found.');
  fs.readFile(p, (err, buf) => {
    if (err) return notFoundApp(req, res, 'Not found.');
    res.writeHead(200, {
      'content-type': mimeFor(p), 'content-length': buf.length,
      'cache-control': 'no-cache',
    });
    res.end(req.method === 'HEAD' ? undefined : buf);
  });
}

function notFoundApp(req, res, msg, code = 404) {
  const html = `<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>${code} — Droply</title>
<style>
*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;background:#0b0d12;
color:#e6e9ef;font:16px/1.5 ui-sans-serif,system-ui,-apple-system,Segoe UI,Roboto,sans-serif;text-align:center;padding:24px}
.wrap{max-width:520px}code{color:#32e6c4}a{color:#32e6c4}
h1{font-size:64px;margin:0 0 8px;background:linear-gradient(90deg,#32e6c4,#7c8cff);-webkit-background-clip:text;background-clip:text;color:transparent}
p{color:#9aa3b2}b{color:#e6e9ef;font-weight:600}
</style></head><body><div class="wrap">
<h1>${code}</h1><p>${msg}</p>
<p><a href="/">← Back to Droply</a></p></div></body></html>`;
  const b = Buffer.from(html);
  res.writeHead(code, { 'content-type': 'text/html; charset=utf-8', 'content-length': b.length });
  res.end(req.method === 'HEAD' ? undefined : b);
}

/* ------------------------------------------------------------------ *
 * API
 * ------------------------------------------------------------------ */

async function apiRouter(req, res, urlPath, body) {
  const method = req.method;
  const send = (c, o) => sendJson(res, c, o);

  // GET /api/state
  if (urlPath === '/api/state' && method === 'GET') {
    return send(200, {
      ok: true,
      sites: store.sites.map(s => siteView(s, req)),
      stats: {
        sites: store.sites.length,
        deploys: store.sites.reduce((n, s) => n + s.deploys.length, 0),
        visits: store.sites.reduce((n, s) => n + (s.visits || 0), 0),
        bytes: store.sites.reduce((n, s) => n + (s.bytes || 0), 0),
      },
    });
  }

  // GET /api/sites
  if (urlPath === '/api/sites' && method === 'GET') {
    return send(200, { ok: true, sites: store.sites.map(s => siteView(s, req)) });
  }

  // POST /api/deploy  (quick deploy — creates or updates a site)
  if (urlPath === '/api/deploy' && method === 'POST') {
    let payload;
    try { payload = JSON.parse(body.toString('utf8')); } catch (e) { return send(400, { ok: false, error: 'Invalid JSON body' }); }
    const { files, name, slug, message, source, siteId } = payload;
    if (!Array.isArray(files) || !files.length) return send(400, { ok: false, error: 'No files received' });

    let site = siteId ? findSite(siteId) : null;
    if (site) {
      const dep = addDeploy(site, { files, message, source });
      return send(200, { ok: true, site: siteView(site, req), deploy: dep });
    }
    site = createSite({ name: name || 'my-site', slug, files, message, source });
    return send(201, { ok: true, site: siteView(site, req), deploy: site.deploys[0] });
  }

  // POST /api/import-github
  if (urlPath === '/api/import-github' && method === 'POST') {
    let payload;
    try { payload = JSON.parse(body.toString('utf8')); } catch (e) { return send(400, { ok: false, error: 'Invalid JSON body' }); }
    const repo = String(payload.repo || '').trim();
    const m = repo.match(/github\.com\/([\w.-]+)\/([\w.-]+?)(?:\.git)?(?:\/tree\/[\w.-]+\/([\w.-]+))?\/?$/i)
      || repo.match(/^([\w.-]+)\/([\w.-]+)$/);
    if (!m) return send(400, { ok: false, error: 'Use a GitHub URL like github.com/owner/repo' });
    const [, owner, name, branch] = m;
    const wanted = payload.branch || branch || null;
    try {
      const zipBuf = await githubArchive(owner, name, wanted);
      const usedRef = githubArchive.lastRef || 'default';
      let entries = unzip(zipBuf).map(e => ({ path: e.path, b64: e.buf.toString('base64') }));
      entries = stripCommonRoot(entries);
      if (!entries.length) return send(400, { ok: false, error: 'Repository archive was empty' });
      const site = createSite({
        name: payload.name || name,
        slug: payload.slug || name,
        files: entries,
        message: `Imported ${owner}/${name}@${usedRef}`,
        source: 'github',
      });
      return send(201, { ok: true, site: siteView(site, req), deploy: site.deploys[0] });
    } catch (e) {
      return send(502, { ok: false, error: 'Import failed: ' + e.message });
    }
  }

  // GET /api/domains/tlds
  if (urlPath === '/api/domains/tlds' && method === 'GET') {
    return send(200, {
      ok: true,
      tlds: Object.entries(TLD_PRICE).map(([tld, [reg, renew]]) => ({ tld, reg, renew })),
    });
  }

  // GET /api/domains  (owned)
  if (urlPath === '/api/domains' && method === 'GET') {
    return send(200, { ok: true, domains: store.domains.map(domainView), orders: store.orders.slice(0, 20) });
  }

  // POST /api/domains/search
  if (urlPath === '/api/domains/search' && method === 'POST') {
    let p = {}; try { p = JSON.parse(body.toString('utf8') || '{}'); } catch (e) { }
    const q = String(p.query || '').trim();
    const parsed = splitDomain(q);
    const sld = parsed ? parsed.sld : q.replace(/[^a-z0-9-]/gi, '').toLowerCase();
    const results = [];
    // If the user typed a full name, check exactly that first.
    if (parsed) {
      const exact = domainInfo(q);
      if (exact) results.push(exact);
    }
    for (const alt of ['com', 'io', 'dev', 'net', 'co', 'app', 'ai', 'xyz', 'org', 'me']) {
      if (!sld) break;
      const nm = `${sld}.${alt}`;
      if (results.some(r => r.name === nm)) continue;
      const info = domainInfo(nm);
      if (info) results.push(info);
    }
    // Put the exact match first if the query was a full domain.
    if (parsed) results.sort((a, b) => (b.name === parsed.name) - (a.name === parsed.name));
    const suggestions = suggestNames(sld || q, 8)
      .filter(x => !results.some(r => r.name === x.name));
    return send(200, { ok: true, query: q, results: results.filter(Boolean), suggestions });
  }

  // POST /api/domains/purchase
  if (urlPath === '/api/domains/purchase' && method === 'POST') {
    let p; try { p = JSON.parse(body.toString('utf8')); } catch (e) { return send(400, { ok: false, error: 'Invalid JSON' }); }
    try {
      // Quote-only preview when no card is supplied.
      if (!p.card) {
        const info = domainInfo(p.name);
        if (!info) return send(400, { ok: false, error: 'That is not a valid domain name' });
        if (!info.available) return send(409, { ok: false, error: `${info.name} is not available` });
        const y = Math.min(10, Math.max(1, parseInt(p.years, 10) || 1));
        const subtotal = +(info.price * y).toFixed(2);
        const icann = +(0.18 * y).toFixed(2);
        const tax = +((subtotal + icann) * 0.0875).toFixed(2);
        return send(200, { ok: true, quote: { name: info.name, price: info.price, premium: info.premium,
          years: y, subtotal, icann, tax, total: +(subtotal + icann + tax).toFixed(2) } });
      }
      const { domain, order } = purchaseDomain(p, req);
      return send(201, { ok: true, domain: domainView(domain), order });
    } catch (e) {
      return send(e.code || 400, { ok: false, error: e.message });
    }
  }

  const mDom = urlPath.match(/^\/api\/domains\/([\w.-]+)(\/[\w-]+)?$/);
  if (mDom) {
    const d = findDomain(mDom[1]);
    if (!d) return send(404, { ok: false, error: 'Domain not found' });
    const act = mDom[2] || '';

    if (act === '' && method === 'DELETE') {
      store.domains = store.domains.filter(x => x.id !== d.id);
      for (const s of store.sites) if (s.primaryDomain === d.name) s.primaryDomain = null;
      saveNow();
      return send(200, { ok: true });
    }
    if (act === '/attach' && method === 'POST') {
      let p; try { p = JSON.parse(body.toString('utf8')); } catch (e) { return send(400, { ok: false, error: 'Invalid JSON' }); }
      const site = findSite(p.siteId);
      if (!site) return send(404, { ok: false, error: 'Site not found' });
      d.siteId = site.id;
      d.dns = { type: 'CNAME', value: dnsTarget(req) };
      d.ssl.status = 'issued';
      site.primaryDomain = d.name;
      site.updatedAt = Date.now();
      saveNow();
      return send(200, { ok: true, domain: domainView(d), site: siteView(site, req) });
    }
    if (act === '/detach' && method === 'POST') {
      for (const s of store.sites) if (s.primaryDomain === d.name) s.primaryDomain = null;
      d.siteId = null;
      d.dns = { type: 'A', value: dnsTarget(req) };
      saveNow();
      return send(200, { ok: true, domain: domainView(d) });
    }
    if (act === '/renew' && method === 'POST') {
      let p = {}; try { p = JSON.parse(body.toString('utf8') || '{}'); } catch (e) { }
      const y = Math.min(10, Math.max(1, parseInt(p.years, 10) || 1));
      const tldPrice = TLD_PRICE[d.tld] || [19, 21];
      const cur = new Date(Math.max(d.expiresAt, Date.now()));
      cur.setFullYear(cur.getFullYear() + y);
      d.expiresAt = cur.getTime();
      d.years = (d.years || 1) + y;
      const subtotal = +(tldPrice[1] * y).toFixed(2);
      const icann = +(0.18 * y).toFixed(2);
      const tax = +((subtotal + icann) * 0.0875).toFixed(2);
      const order = { id: 'ord_' + randId(6), domain: d.name, createdAt: Date.now(),
        subtotal, icann, tax, total: +(subtotal + icann + tax).toFixed(2), years: y,
        card: p.card ? { brand: cardBrand(p.card.number), last4: String(p.card.number).replace(/\D/g, '').slice(-4) } : null, renewal: true };
      if (p.card && !luhn(p.card.number)) return send(402, { ok: false, error: 'Card number is invalid' });
      store.orders.unshift(order);
      saveNow();
      return send(200, { ok: true, domain: domainView(d), order });
    }
    if (act === '/autorenew' && method === 'PATCH') {
      let p = {}; try { p = JSON.parse(body.toString('utf8') || '{}'); } catch (e) { }
      d.autoRenew = !!p.autoRenew;
      saveNow();
      return send(200, { ok: true, domain: domainView(d) });
    }
    return send(404, { ok: false, error: 'Unknown endpoint' });
  }

  const mSite = urlPath.match(/^\/api\/sites\/([\w-]+)(\/.*)?$/);
  if (mSite) {
    const id = mSite[1];
    const rest = mSite[2] || '';
    const site = findSite(id);
    if (!site) return send(404, { ok: false, error: 'Site not found' });

    if (rest === '' && method === 'GET') {
      return send(200, { ok: true, site: { ...siteView(site, req), deploys: site.deploys } });
    }
    if (rest === '' && method === 'PATCH') {
      let p; try { p = JSON.parse(body.toString('utf8')); } catch (e) { return send(400, { ok: false, error: 'Invalid JSON' }); }
      if (p.name) site.name = String(p.name).slice(0, 60);
      if (p.slug) {
        const want = slugify(p.slug);
        if (store.sites.some(s => s.slug === want && s.id !== site.id)) return send(409, { ok: false, error: 'That URL is already taken' });
        site.slug = want;
      }
      site.updatedAt = Date.now();
      save();
      return send(200, { ok: true, site: siteView(site, req) });
    }
    if (rest === '' && method === 'DELETE') {
      fs.rmSync(path.join(SITES_DIR, site.id), { recursive: true, force: true });
      store.sites = store.sites.filter(s => s.id !== site.id);
      for (const d of store.domains) if (d.siteId === site.id) { d.siteId = null; d.dns = { type: 'A', value: dnsTarget(req) }; }
      saveNow();
      return send(200, { ok: true });
    }
    if (rest === '/deploys' && method === 'POST') {
      let p; try { p = JSON.parse(body.toString('utf8')); } catch (e) { return send(400, { ok: false, error: 'Invalid JSON' }); }
      if (!Array.isArray(p.files) || !p.files.length) return send(400, { ok: false, error: 'No files received' });
      const dep = addDeploy(site, { files: p.files, message: p.message, source: p.source });
      return send(201, { ok: true, deploy: dep, site: siteView(site, req) });
    }
    const mDep = rest.match(/^\/deploys\/([\w-]+)(\/activate)?$/);
    if (mDep) {
      const dep = site.deploys.find(d => d.id === mDep[1]);
      if (!dep) return send(404, { ok: false, error: 'Deploy not found' });
      if (mDep[2] === '/activate' && method === 'POST') {
        site.activeDeploy = dep.id;
        site.updatedAt = Date.now();
        saveNow();
        return send(200, { ok: true, site: siteView(site, req), deploy: dep });
      }
      if (!mDep[2] && method === 'DELETE') {
        if (site.deploys.length <= 1) return send(400, { ok: false, error: 'A site must keep at least one deploy' });
        site.deploys = site.deploys.filter(d => d.id !== dep.id);
        if (site.activeDeploy === dep.id) site.activeDeploy = site.deploys[0].id;
        deleteDeployDir(site.id, dep.id);
        saveNow();
        return send(200, { ok: true, site: siteView(site, req) });
      }
    }
    return send(404, { ok: false, error: 'Unknown endpoint' });
  }

  return send(404, { ok: false, error: 'Unknown endpoint' });
}

// Fetch a repo archive, resolving the default branch when none is given.
async function githubArchive(owner, name, wanted) {
  const tries = [];
  if (wanted) tries.push(wanted);
  try {
    const meta = await download(`https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(name)}`);
    const dflt = JSON.parse(meta.toString('utf8')).default_branch;
    if (dflt && !tries.includes(dflt)) tries.push(dflt);
  } catch (e) { /* API unavailable or rate-limited — fall through to guesses */ }
  for (const t of ['main', 'master', 'trunk', 'develop']) if (!tries.includes(t)) tries.push(t);

  let lastErr;
  for (const ref of tries) {
    try {
      const buf = await download(`https://codeload.github.com/${encodeURIComponent(owner)}/${encodeURIComponent(name)}/zip/refs/heads/${encodeURIComponent(ref)}`);
      githubArchive.lastRef = ref;
      return buf;
    } catch (e) { lastErr = e; if (ref === wanted) throw e; }
  }
  throw lastErr || new Error('Could not download the repository archive');
}

function download(url, redirects = 3) {
  return new Promise((resolve, reject) => {
    https.get(url, { headers: { 'user-agent': 'Droply/1.0' } }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location && redirects > 0) {
        res.resume();
        return download(new URL(res.headers.location, url).href, redirects - 1).then(resolve, reject);
      }
      if (res.statusCode !== 200) { res.resume(); return reject(new Error('HTTP ' + res.statusCode)); }
      const chunks = []; let size = 0;
      res.on('data', c => {
        size += c.length;
        if (size > 60 * 1024 * 1024) { reject(new Error('archive too large')); res.destroy(); return; }
        chunks.push(c);
      });
      res.on('end', () => resolve(Buffer.concat(chunks)));
      res.on('error', reject);
    }).on('error', reject);
  });
}

/* ------------------------------------------------------------------ *
 * Domains — search, price, checkout, DNS
 * ------------------------------------------------------------------ */

// Yearly prices in USD (registration + renewal).
const TLD_PRICE = {
  com: [12.00, 14.00], net: [13.50, 15.50], org: [11.00, 13.00], io: [38.00, 44.00],
  dev: [14.00, 16.00], app: [15.00, 17.00], co: [26.00, 30.00], ai: [72.00, 82.00],
  xyz: [2.00, 12.00], me: [18.00, 20.00], sh: [29.00, 33.00], page: [9.00, 11.00],
  site: [3.50, 24.00], online: [2.50, 26.00], store: [4.00, 32.00], blog: [5.00, 22.00],
  tech: [6.00, 34.00], fun: [3.00, 22.00], cloud: [8.00, 24.00], cc: [9.00, 12.00],
};
const HOT = new Set(['ai', 'shop', 'app', 'crypto', 'dev', 'cloud', 'labs', 'web', 'host', 'pixel',
  'nova', 'orbit', 'wave', 'core', 'data', 'swift', 'zen', 'luxe', 'neo', 'flux']);

const hashInt = (s, mod) => parseInt(crypto.createHash('sha1').update(String(s)).digest('hex').slice(0, 8), 16) % mod;

function splitDomain(input) {
  const d = String(input || '').trim().toLowerCase()
    .replace(/^https?:\/\//, '').replace(/^www\./, '').replace(/\/.*$/, '').replace(/\.$/, '');
  if (!/^[a-z0-9-]+(\.[a-z0-9-]+)+$/.test(d) || d.includes('..')) return null;
  const parts = d.split('.');
  const tld = parts.pop();
  const sld = parts.pop();
  const sub = parts.join('.');
  if (!/^[a-z0-9][a-z0-9-]{0,62}[a-z0-9]$/.test(sld)) return null;
  return { sld, tld, sub, name: `${sld}.${tld}` };
}

// Deterministic, fake-but-plausible availability + pricing.
function domainInfo(name) {
  const p = splitDomain(name);
  if (!p) return null;
  const tldPrice = TLD_PRICE[p.tld];
  const owned = store.domains.find(d => d.name === p.name);
  let available, premium = false, price, renew;

  if (owned) {
    return { name: p.name, sld: p.sld, tld: p.tld, available: false, owned: true, premium: false,
      price: owned.price, renew: tldPrice ? tldPrice[1] : null, expiresAt: owned.expiresAt, siteId: owned.siteId };
  }
  if (!tldPrice) {
    return { name: p.name, sld: p.sld, tld: p.tld, available: false, owned: false, premium: false,
      price: null, renew: null, unsupportedTld: true };
  }

  const short = p.sld.length <= 4;
  const keyword = HOT.has(p.sld) || /^[a-z]{3,6}$/.test(p.sld) && hashInt(p.sld, 4) === 0;
  const roll = hashInt(p.name, 100);
  available = short ? roll < 9 : keyword ? roll < 22 : roll < 46;
  premium = available && (short || keyword);

  if (premium) {
    // Premium aftermarket pricing: short/dictionary names cost real money.
    const base = short ? 2400 : 320;
    price = Math.round((base + hashInt(p.name + 'prem', short ? 42000 : 2400)) / 10) * 10;
    renew = tldPrice[1];
  } else {
    price = tldPrice[0];
    renew = tldPrice[1];
  }
  return { name: p.name, sld: p.sld, tld: p.tld, available, owned: false, premium, price, renew };
}

function suggestNames(query, n = 8) {
  const base = String(query || '').trim().toLowerCase().replace(/[^a-z0-9]/g, '');
  const roots = base ? [base] : ['mystore', 'launchpad', 'northwind'];
  const prefixes = ['', 'get', 'my', 'the', 'try', 'go', 'use'];
  const suffixes = ['', 'hq', 'app', 'lab', 'labs', 'web', 'hub', 'now', 'site', 'online'];
  const tlds = ['com', 'com', 'net', 'io', 'dev', 'co', 'org', 'app', 'xyz'];
  const seen = new Set(); const out = [];
  for (const r of roots) {
    for (const pre of prefixes) for (const suf of suffixes) {
      const sld = pre + r + suf;
      if (sld.length < 3 || sld.length > 24) continue;
      const tld = tlds[hashInt(sld + 't', tlds.length)];
      const nm = `${sld}.${tld}`;
      if (seen.has(nm)) continue;
      seen.add(nm);
      out.push(nm);
      if (out.length >= n * 4) break;
    }
    if (out.length >= n * 4) break;
  }
  return out.map(domainInfo).filter(Boolean).sort((a, b) => {
    if (a.available !== b.available) return a.available ? -1 : 1;
    return (a.price || 0) - (b.price || 0);
  }).slice(0, n);
}

function luhn(num) {
  const s = String(num).replace(/\D/g, '');
  if (s.length < 13 || s.length > 19) return false;
  let sum = 0, alt = false;
  for (let i = s.length - 1; i >= 0; i--) {
    let d = +s[i];
    if (alt) { d *= 2; if (d > 9) d -= 9; }
    sum += d; alt = !alt;
  }
  return sum % 10 === 0;
}
function cardBrand(num) {
  const s = String(num).replace(/\D/g, '');
  if (/^4/.test(s)) return 'Visa';
  if (/^5[1-5]/.test(s)) return 'Mastercard';
  if (/^3[47]/.test(s)) return 'Amex';
  if (/^6(?:011|5)/.test(s)) return 'Discover';
  return 'Card';
}

function dnsTarget(req) {
  const host = (req.headers['x-forwarded-host'] || req.headers.host || `localhost:${PORT}`).split(',')[0].trim();
  return host.split(':')[0];
}

function purchaseDomain({ name, years, siteId, card }, req) {
  const info = domainInfo(name);
  if (!info) throw Object.assign(new Error('That is not a valid domain name'), { code: 400 });
  if (info.owned) throw Object.assign(new Error(`${info.name} is already in your account`), { code: 409 });
  if (!info.available) throw Object.assign(new Error(`${info.name} is already registered. Try another name or extension.`), { code: 409 });

  // --- payment (sandbox: card is validated, never stored) ---
  if (!card || !luhn(card.number)) throw Object.assign(new Error('Card number is invalid — check the digits'), { code: 402 });
  const [mm, yy] = String(card.expiry || '').split('/').map(s => (s || '').trim());
  const now = new Date();
  const expOk = /^\d{2}$/.test(mm) && /^\d{2,4}$/.test(yy) &&
    (+mm >= 1 && +mm <= 12) &&
    (new Date(2000 + (+yy % 100), +mm, 0) >= new Date(now.getFullYear(), now.getMonth(), 1));
  if (!expOk) throw Object.assign(new Error('Card expiry date is invalid'), { code: 402 });
  if (!/^\d{3,4}$/.test(String(card.cvc || ''))) throw Object.assign(new Error('Security code (CVC) is invalid'), { code: 402 });
  if (String(card.zip || '').trim().length < 3) throw Object.assign(new Error('Billing ZIP is required'), { code: 402 });

  const yearsN = Math.min(10, Math.max(1, parseInt(years, 10) || 1));
  const subtotal = +(info.price * yearsN).toFixed(2);
  const icann = +(0.18 * yearsN).toFixed(2);
  const tax = +((subtotal + icann) * 0.0875).toFixed(2);
  const total = +(subtotal + icann + tax).toFixed(2);

  const exp = new Date();
  exp.setFullYear(exp.getFullYear() + yearsN);

  const rec = {
    id: randId(6),
    name: info.name,
    sld: info.sld,
    tld: info.tld,
    price: info.price,
    premium: !!info.premium,
    years: yearsN,
    purchasedAt: Date.now(),
    expiresAt: exp.getTime(),
    autoRenew: true,
    privacy: true,
    status: 'active',
    siteId: siteId || null,
    dns: { type: siteId ? 'CNAME' : 'A', value: dnsTarget(req) },
    ssl: { status: 'issued', issuer: "Let's Encrypt", issuedAt: Date.now(), expiresAt: exp.getTime() },
  };
  store.domains.unshift(rec);

  const order = {
    id: 'ord_' + randId(6),
    domain: info.name,
    createdAt: Date.now(),
    subtotal, icann, tax, total,
    years: yearsN,
    card: { brand: cardBrand(card.number), last4: String(card.number).replace(/\D/g, '').slice(-4) },
  };
  store.orders.unshift(order);

  if (siteId) {
    const site = findSite(siteId);
    if (site) { site.primaryDomain = info.name; site.updatedAt = Date.now(); }
  }
  saveNow();
  return { domain: rec, order };
}

function domainView(d) {
  return {
    id: d.id, name: d.name, price: d.price, premium: d.premium, years: d.years,
    purchasedAt: d.purchasedAt, expiresAt: d.expiresAt, autoRenew: d.autoRenew, privacy: d.privacy,
    status: d.status, siteId: d.siteId, dns: d.dns, ssl: d.ssl,
  };
}

function findDomain(idOrName) {
  return store.domains.find(d => d.id === idOrName || d.name === idOrName);
}

/* ------------------------------------------------------------------ *
 * Server
 * ------------------------------------------------------------------ */

const server = http.createServer(async (req, res) => {
  const started = Date.now();
  let urlPath;
  try {
    urlPath = decodeURIComponent(new URL(req.url, 'http://localhost').pathname);
  } catch (e) {
    urlPath = req.url.split('?')[0];
  }

  // The UI and its JSON API are same-origin; do not enable wildcard CORS on a
  // host that may serve user-uploaded JavaScript.
  if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }

  // Small public health check for managed hosts (e.g. Railway).
  if (req.method === 'GET' && urlPath === '/healthz') {
    return sendJson(res, 200, { ok: true });
  }

  try {
    // Route site hostnames before the platform API so an uploaded site cannot
    // shadow or call the management API from its own origin.
    const host = hostnameFromRequest(req);
    const hostedSlug = siteSlugFromHost(host);
    if (hostedSlug) return servePublished(req, res, hostedSlug, urlPath);

    // Custom domain routing: a domain pointed at this host serves the site at
    // every path, including paths named /api or /static.
    if (host && host !== 'localhost' && !/^[\d.]+$/.test(host) && !host.endsWith('.e2b.app')) {
      const bare = host.replace(/^www\./, '');
      const dom = store.domains.find(d => d.siteId && (d.name === host || d.name === bare));
      if (dom) {
        const site = findSite(dom.siteId);
        if (site) return servePublished(req, res, site.slug, urlPath);
      }
    }

    if (urlPath.startsWith('/api/')) {
      const body = (req.method === 'GET' || req.method === 'HEAD') ? Buffer.alloc(0) : await readBody(req);
      return await apiRouter(req, res, urlPath, body);
    }

    // Published sites: /s/<slug>/...
    if (urlPath === '/s' || urlPath.startsWith('/s/')) {
      const rest = urlPath.slice(2).replace(/^\/+/, '');
      if (!rest) return notFoundApp(req, res, 'Pick a site to visit.');
      const [slug, ...pathParts] = rest.split('/');
      if (pathParts.length === 0) {
        res.writeHead(302, { location: `/s/${slug}/` });
        return res.end();
      }
      return servePublished(req, res, slug, '/' + pathParts.join('/'));
    }

    if (urlPath === '/sites') { res.writeHead(302, { location: '/dashboard' }); return res.end(); }

    return serveAppFile(req, res, urlPath === '/' ? '/' : urlPath.replace(/\/+$/, '') || '/');
  } catch (err) {
    console.error(req.method, urlPath, err.message);
    if (!res.headersSent) {
      const b = Buffer.from('Server error: ' + err.message);
      res.writeHead(500, { 'content-type': 'text/plain', 'content-length': b.length });
      res.end(req.method === 'HEAD' ? undefined : b);
    }
  } finally {
    if (process.env.DROPLY_LOG) {
      console.log(`${req.method} ${urlPath} → ${res.statusCode} ${Date.now() - started}ms`);
    }
  }
});

server.listen(PORT, HOST, () => {
  console.log(`\n  ▲ Droply is live`);
  console.log(`   - Local:   http://localhost:${PORT}`);
  console.log(`   - Sites:   /s/<slug>/`);
  console.log(`   - Data:    ${DATA_DIR}\n`);
});

for (const sig of ['SIGINT', 'SIGTERM']) {
  process.on(sig, () => { saveNow(); process.exit(0); });
}

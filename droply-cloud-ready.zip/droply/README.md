# ▲ Droply

A small self-hosted static deploy platform inspired by Netlify. **Zero npm dependencies, pure Node.**

Deploy a folder, a `.zip`, pasted HTML or a public GitHub repo — and get a live URL on the server running Droply. Domain search and a simulated checkout are included; real registration and payment providers are not integrated yet.

```bash
node server.js        # http://localhost:3000
PORT=8080 node server.js
DROPLY_LOG=1 node server.js   # request logging
```

## What's in it

| Area | What works |
|---|---|
| **Deploys** | Drag & drop a folder, pick files, upload a `.zip` (extracted server-side), paste HTML, or import a public GitHub repo |
| **Hosting** | Sites are served at `/s/<slug>/` by default, or on optional wildcard subdomains; clean URLs, `404.html`, and MIME types are supported |
| **Rollbacks** | Every deploy is an immutable snapshot; the 20 newest are kept and any one can be promoted to production instantly |
| **Analytics** | Page views, uniques, bandwidth and top paths — per deploy, per day, no tracking script |
| **Domains** | Search 20+ TLDs, see availability + premium pricing, buy with a (sandbox) card, attach to a site, renew, auto-renew, receipts |
| **Custom-domain routing** | Requests whose `Host` header matches a purchased domain are served that site's content |

## Put it on the public internet (Railway)

The in-app sandbox preview is temporary and is not a permanent public host. This project now includes a Docker image and persistent-data support so you can run the deploy server on a public host. Railway is the simplest managed option for this Node app; a Docker-capable VPS works too.

1. Put the `droply` folder in a GitHub repository and create a Railway project using **Deploy from GitHub repo**. Railway detects the included `Dockerfile` and builds the app.
2. In the Railway service, attach a persistent volume mounted at **`/app/data`**. Droply writes its site files and metadata there; without a persistent volume, redeploys/restarts can lose user deployments. Railway documents mounting a volume at `/app/data` for apps that write to `./data` from `/app` ([volume guide](https://docs.railway.com/volumes)).
3. Set the service health check path to **`/healthz`** (the Dockerfile also includes a health check).
4. In the service's **Networking** settings, generate a public domain. The dashboard will then provide live site links such as `https://YOUR-SERVICE.up.railway.app/s/your-site/`.
5. Keep this service at **one replica**. The current metadata store is a local JSON file, so multiple instances could overwrite each other.

### Optional Netlify-style site subdomains

If you own a domain and can configure wildcard DNS, set `DROPLY_SITES_DOMAIN=sites.example.com` and point `*.sites.example.com` at the service. A site's URL then becomes `https://your-site.sites.example.com/`. Keep the dashboard on a different hostname; the wildcard site hostname must resolve to this same service. Without this setting, the normal `/s/<slug>/` URLs work.

### Important production limits

- Railway and other hosts may charge for compute, storage, and bandwidth. Free allowances are limited and can change; check the provider's current plan before launching. Railway's current plan page lists a limited Free tier and 0.5 GB maximum volume storage ([pricing](https://docs.railway.com/pricing/plans)).
- This is still a **single-owner MVP**, not a public multi-tenant Netlify clone: it has no user accounts, per-user permissions, abuse controls, or build pipeline. Don't open the dashboard/upload API to the general public until those controls are added.
- The domain search/registration, SSL status, and checkout are simulated. They do not register domains or collect money. Real custom domains require registration elsewhere and DNS pointed at the service.
- User sites are static files only. Uploaded HTML and JavaScript run in visitors' browsers; use a separate wildcard site domain rather than the dashboard host if you enable `DROPLY_SITES_DOMAIN`.

For a local Docker run with persisted data, use `docker compose up --build` and open `http://localhost:3000`.

## Routes

```
/                 marketing site + instant deploy box
/dashboard        app (overview · new deploy · site detail · domains)
/docs             documentation
/s/<slug>/...     a published site
/api/...          JSON API (see /docs)
```

## API quick reference

```bash
# deploy files
curl -X POST localhost:3000/api/deploy -H 'content-type: application/json' \
  -d '{"name":"hi","files":[{"path":"index.html","content":"<h1>hi</h1>"}]}'

# price a domain (no card = quote only)
curl -X POST localhost:3000/api/domains/purchase -H 'content-type: application/json' \
  -d '{"name":"example.com","years":2}'

# simulate a purchase (test-only card validation; no real charge)
curl -X POST localhost:3000/api/domains/purchase -H 'content-type: application/json' \
  -d '{"name":"example.io","years":1,"card":{"number":"4242424242424242","expiry":"04/29","cvc":"123","zip":"94549"}}'
```

## Notes & limits

- Per deploy: 3,000 files / 40 MB (upload cap 80 MB).
- Static files only — no server-side runtimes or build steps.
- Payments are simulated: card numbers are Luhn-validated, never stored (only brand + last 4), and no money moves.
- Domain availability is deterministic pseudo-random (the same name always gives the same answer), not a live registry lookup.
- Everything lives on disk: `data/store.json` + `data/sites/<site>/<deploy>/…`.

## Files

```
server.js               HTTP server, API, ZIP reader, static file hosting
Dockerfile              production container + health check
docker-compose.yml      local container run with persistent storage
public/index.html       landing page + instant deploy
public/dashboard.html   app shell
public/docs.html        docs
public/static/*.js|css  client
data/                   runtime data; excluded from Git and Docker
```
